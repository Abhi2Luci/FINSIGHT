package com.abhishek.finsight.core;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parses the date formats Indian banks use: 05-11-2026, 05/11/26, 15-Nov-26, 15 Nov 2026, Nov 15, 2026, 2026-11-15. */
public final class Dates {
    private Dates() {}

    private static final String MON = "(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*";
    private static final Pattern NUM = Pattern.compile("^(\\d{1,2})[-/.](\\d{1,2})[-/.](\\d{2,4})$");
    private static final Pattern DMY = Pattern.compile("^(\\d{1,2})(?:st|nd|rd|th)?[\\s\\-/.,]+" + MON + "[\\s\\-/.,]+(\\d{2,4})$");
    private static final Pattern MDY = Pattern.compile("^" + MON + "\\s+(\\d{1,2})(?:st|nd|rd|th)?,?\\s+(\\d{4})$");
    private static final Pattern ISO = Pattern.compile("^(\\d{4})-(\\d{2})-(\\d{2})$");

    /** @return start of that day in millis, or -1 if it cannot be read. */
    public static long parse(String s) {
        if (s == null) return -1;
        String t = s.trim().toLowerCase(Locale.ROOT);
        try {
            Matcher m = ISO.matcher(t);
            if (m.find()) return millis(i(m.group(1)), i(m.group(2)), i(m.group(3)));
            m = NUM.matcher(t);
            if (m.find()) {
                int a = i(m.group(1)), b = i(m.group(2));
                int d = a, mo = b;
                if (b > 12 && a <= 12) { d = b; mo = a; }
                return millis(year(m.group(3)), mo, d);
            }
            m = DMY.matcher(t);
            if (m.find()) return millis(year(m.group(3)), month(m.group(2)), i(m.group(1)));
            m = MDY.matcher(t);
            if (m.find()) return millis(year(m.group(3)), month(m.group(1)), i(m.group(2)));
        } catch (Exception ignored) {
        }
        return -1;
    }

    private static int i(String s) {
        return Integer.parseInt(s);
    }

    private static int year(String s) {
        int y = Integer.parseInt(s);
        return y < 100 ? 2000 + y : y;
    }

    private static int month(String s) {
        String[] names = {"jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"};
        String p = s.substring(0, 3);
        for (int k = 0; k < 12; k++) if (names[k].equals(p)) return k + 1;
        return -1;
    }

    private static long millis(int y, int m, int d) {
        if (m < 1 || m > 12 || d < 1 || d > 31 || y < 2000 || y > 2100) return -1;
        return LocalDate.of(y, m, d).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }
}
