package com.abhishek.finsight;

import android.app.Notification;
import android.content.ComponentName;
import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import com.abhishek.finsight.core.RawMessage;

import java.util.ArrayList;
import java.util.List;

/**
 * Sees new notifications (WhatsApp, Telegram, bank apps...). Only messages the parser
 * recognises as financial are saved; everything else is ignored immediately.
 */
public class NotifService extends NotificationListenerService {

    static boolean enabled(Context c) {
        String flat = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
        if (flat == null) return false;
        String me = new ComponentName(c, NotifService.class).flattenToString();
        return flat.contains(me) || flat.contains(c.getPackageName() + "/");
    }

    static String sourceName(String pkg) {
        switch (pkg) {
            case "com.whatsapp": return "WhatsApp";
            case "com.whatsapp.w4b": return "WhatsApp Business";
            case "org.telegram.messenger":
            case "org.telegram.messenger.web":
            case "org.telegram.plus":
            case "org.thunderdog.challegram": return "Telegram";
            default: return "App notification";
        }
    }

    /** SMS and Gmail are read directly, so their notifications would only be duplicates. */
    private static boolean skip(String pkg) {
        return pkg.equals("com.google.android.apps.messaging") || pkg.equals("com.samsung.android.messaging")
                || pkg.equals("com.android.mms") || pkg.equals("com.google.android.gm") || pkg.equals("android")
                || pkg.equals("com.android.systemui") || pkg.startsWith("com.abhishek.finsight");
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            String pkg = sbn.getPackageName();
            if (pkg == null || skip(pkg)) return;
            Notification n = sbn.getNotification();
            if (n == null || n.extras == null) return;
            Bundle ex = n.extras;
            String source = sourceName(pkg);
            String title = str(ex.getCharSequence(Notification.EXTRA_TITLE));
            if (source.equals("App notification")) source = "App: " + appLabel(pkg);

            List<RawMessage> found = new ArrayList<>();
            Parcelable[] msgs = ex.getParcelableArray(Notification.EXTRA_MESSAGES);
            if (msgs != null && msgs.length > 0) {
                for (Parcelable p : msgs) {
                    if (!(p instanceof Bundle)) continue;
                    Bundle b = (Bundle) p;
                    String text = str(b.getCharSequence("text"));
                    long t = b.getLong("time", sbn.getPostTime());
                    String sender = str(b.getCharSequence("sender"));
                    String who = title.isEmpty() ? sender : (sender.isEmpty() || sender.equals(title) ? title : title + " / " + sender);
                    if (!text.isEmpty()) found.add(new RawMessage(source, who, t, text));
                }
            } else {
                String text = str(ex.getCharSequence(Notification.EXTRA_BIG_TEXT));
                if (text.isEmpty()) text = str(ex.getCharSequence(Notification.EXTRA_TEXT));
                if (!text.isEmpty()) found.add(new RawMessage(source, title, sbn.getPostTime(), text));
            }
            if (!found.isEmpty()) Store.get(this).saveFinancial(found);
        } catch (Exception ignored) {
        }
    }

    private String appLabel(String pkg) {
        try {
            return String.valueOf(getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0)));
        } catch (Exception e) {
            return pkg;
        }
    }

    private static String str(CharSequence cs) {
        return cs == null ? "" : cs.toString().trim();
    }
}
