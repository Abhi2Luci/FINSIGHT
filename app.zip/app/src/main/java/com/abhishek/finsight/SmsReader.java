package com.abhishek.finsight;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;

import com.abhishek.finsight.core.RawMessage;

import java.util.ArrayList;
import java.util.List;

/** Reads the phone's SMS inbox. Nothing is uploaded or copied. */
final class SmsReader {
    private SmsReader() {}

    static boolean allowed(Context c) {
        return c.checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    static List<RawMessage> read(Context c, int days) {
        List<RawMessage> out = new ArrayList<>();
        if (!allowed(c)) return out;
        long since = System.currentTimeMillis() - days * 86400000L;
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(Uri.parse("content://sms/inbox"),
                    new String[]{"address", "body", "date"}, "date > ?",
                    new String[]{String.valueOf(since)}, "date DESC");
            if (cur == null) return out;
            while (cur.moveToNext()) {
                String body = cur.getString(1);
                if (body == null) continue;
                out.add(new RawMessage("SMS", cur.getString(0), cur.getLong(2), body));
            }
        } catch (Exception ignored) {
        } finally {
            if (cur != null) cur.close();
        }
        return out;
    }
}
