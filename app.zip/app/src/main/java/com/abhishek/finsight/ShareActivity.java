package com.abhishek.finsight;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Receives "Share → FinSight" from WhatsApp chat export, Telegram, file managers or copied text. */
public class ShareActivity extends Activity {
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTitle("Import to FinSight");
        LinearLayout l = Ui.vbox(this);
        l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(Ui.BG);
        int p = Ui.dp(this, 28);
        l.setPadding(p, p, p, p);
        l.addView(new ProgressBar(this));
        TextView t = Ui.text(this, "Importing…", 15, Ui.INK, false);
        t.setGravity(Gravity.CENTER);
        l.addView(t);
        setContentView(l);

        Intent in = getIntent();
        List<Uri> uris = new ArrayList<>();
        String text = null;
        String subject = in.getStringExtra(Intent.EXTRA_SUBJECT);
        if (Intent.ACTION_SEND.equals(in.getAction())) {
            Uri u = in.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) uris.add(u);
            CharSequence cs = in.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (cs != null) text = cs.toString();
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(in.getAction())) {
            ArrayList<Uri> list = in.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (list != null) uris.addAll(list);
        }
        final String sharedText = text;
        final String chat = subject == null ? "" : Importer.chatName(subject);

        new Thread(() -> {
            Importer.Result total = new Importer.Result();
            String err = null;
            for (Uri u : uris) {
                try {
                    Importer.Result r = Importer.importUri(this, u);
                    total.messages += r.messages;
                    total.financial += r.financial;
                    total.added += r.added;
                } catch (Exception e) {
                    err = e.getMessage();
                }
            }
            // WhatsApp puts "WhatsApp Chat with X" in the text when it also attaches the file; ignore that
            if (uris.isEmpty() && sharedText != null && !sharedText.trim().isEmpty()) {
                Importer.Result r = Importer.importText(this, sharedText, chat);
                total.messages += r.messages;
                total.financial += r.financial;
                total.added += r.added;
            }
            final String msg = (err != null && total.messages == 0) ? "Import failed: " + err : total.describe();
            ui.post(() -> done(msg));
        }).start();
    }

    private void done(String msg) {
        LinearLayout l = Ui.vbox(this);
        l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(Ui.BG);
        int p = Ui.dp(this, 28);
        l.setPadding(p, p, p, p);
        TextView t = Ui.text(this, msg, 16, Ui.INK, true);
        t.setGravity(Gravity.CENTER);
        l.addView(t);
        l.addView(Ui.button(this, "Open FinSight", v -> {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
            finish();
        }));
        l.addView(Ui.secondaryButton(this, "Done", v -> finish()));
        setContentView(l);
    }
}
