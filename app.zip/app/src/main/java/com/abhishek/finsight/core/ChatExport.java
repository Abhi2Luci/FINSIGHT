package com.abhishek.finsight.core;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads WhatsApp "Export chat" text files (Android and iPhone formats) and plain pasted text. */
public final class ChatExport {
    private ChatExport() {}

    private static final String TIME = "(\\d{1,2}):(\\d{2})(?::(\\d{2}))?\\s*([ap]\\.?\\s?m\\.?)?";
    private static final Pattern ANDROID = Pattern.compile(
            "^(\\d{1,2})[/.\\-](\\d{1,2})[/.\\-](\\d{2,4}),?\\s+" + TIME + "\\s+[-–]\\s+(.*)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern IOS = Pattern.compile(
            "^\\[(\\d{1,2})[/.\\-](\\d{1,2})[/.\\-](\\d{2,4}),?\\s+" + TIME + "\\]\\s+(.*)$", Pattern.CASE_INSENSITIVE);

    public static boolean looksLikeWhatsApp(String text) {
        int checked = 0, hits = 0;
        for (String line : text.split("\n", 60)) {
            String l = clean(line);
            if (l.isEmpty()) continue;
            checked++;
            if (ANDROID.matcher(l).find() || IOS.matcher(l).find()) hits++;
            if (checked >= 20) break;
        }
        return hits >= 1 && hits * 2 >= Math.min(checked, 4);
    }

    public static List<RawMessage> parseWhatsApp(String text, String source, String chatName) {
        List<RawMessage> out = new ArrayList<>();
        String curSender = null;
        long curTime = 0;
        StringBuilder cur = null;
        for (String line : text.split("\n")) {
            String l = clean(line);
            Matcher m = ANDROID.matcher(l);
            if (!m.find()) {
                m = IOS.matcher(l);
                if (!m.find()) m = null;
            }
            if (m != null) {
                if (cur != null) out.add(new RawMessage(source, curSender, curTime, cur.toString()));
                long t = toMillis(m);
                String rest = m.group(8);
                int colon = rest.indexOf(": ");
                String sender = colon > 0 && colon < 60 ? rest.substring(0, colon) : (chatName == null ? "" : chatName);
                String body = colon > 0 && colon < 60 ? rest.substring(colon + 2) : rest;
                curSender = sender.isEmpty() && chatName != null ? chatName : sender;
                if (chatName != null && !chatName.isEmpty() && !curSender.contains(chatName)) curSender = chatName + " / " + curSender;
                curTime = t;
                cur = new StringBuilder(body);
            } else if (cur != null) {
                cur.append('\n').append(l);
            }
        }
        if (cur != null) out.add(new RawMessage(source, curSender, curTime, cur.toString()));
        return out;
    }

    /** Pasted or shared text with no timestamps: split into blocks at blank lines. */
    public static List<RawMessage> parsePlain(String text, String source, String sender, long time) {
        List<RawMessage> out = new ArrayList<>();
        String[] blocks = text.replace("\r", "").split("\n\\s*\n");
        long t = time;
        for (String b : blocks) {
            String s = b.trim();
            if (s.length() < 8) continue;
            out.add(new RawMessage(source, sender, t++, s));
        }
        return out;
    }

    private static String clean(String line) {
        return line.replace('‎', ' ').replace('‏', ' ').replace(' ', ' ')
                .replace(' ', ' ').replace("\r", "").trim();
    }

    private static long toMillis(Matcher m) {
        try {
            int a = Integer.parseInt(m.group(1));
            int b = Integer.parseInt(m.group(2));
            int y = Integer.parseInt(m.group(3));
            if (y < 100) y += 2000;
            int day = a, mon = b;
            if (b > 12 && a <= 12) { day = b; mon = a; }
            int h = Integer.parseInt(m.group(4));
            int min = Integer.parseInt(m.group(5));
            int sec = m.group(6) == null ? 0 : Integer.parseInt(m.group(6));
            String ap = m.group(7);
            if (ap != null) {
                boolean pm = ap.toLowerCase(Locale.ROOT).startsWith("p");
                if (pm && h < 12) h += 12;
                if (!pm && h == 12) h = 0;
            }
            return LocalDateTime.of(y, mon, day, h, min, sec).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        } catch (Exception e) {
            return System.currentTimeMillis();
        }
    }
}
