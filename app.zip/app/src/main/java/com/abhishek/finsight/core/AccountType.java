package com.abhishek.finsight.core;

public enum AccountType {
    SAVINGS("Bank accounts"),
    CREDIT_CARD("Credit cards"),
    LOAN("Loans"),
    DEPOSIT("Fixed / recurring deposits"),
    DEBIT_CARD("Debit cards");

    public final String title;

    AccountType(String title) {
        this.title = title;
    }
}
