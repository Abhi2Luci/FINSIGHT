package com.abhishek.finsight;

import android.content.Context;

import com.abhishek.finsight.core.Aggregator;
import com.abhishek.finsight.core.RawMessage;

import java.util.ArrayList;
import java.util.List;

/** Collects messages from every source and builds the combined picture. */
final class Engine {
    private Engine() {}

    static volatile Aggregator.Result last;
    static volatile long builtAt;

    /** Runs on a background thread. */
    static synchronized Aggregator.Result build(Context c) {
        List<RawMessage> all = new ArrayList<>(SmsReader.read(c, 3 * 365));
        all.addAll(Store.get(c).all());
        Aggregator.Result r = Aggregator.build(all);
        last = r;
        builtAt = System.currentTimeMillis();
        return r;
    }
}
