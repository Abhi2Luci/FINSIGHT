package com.abhishek.finsight;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.abhishek.finsight.core.Account;
import com.abhishek.finsight.core.AccountType;
import com.abhishek.finsight.core.Aggregator;
import com.abhishek.finsight.core.Money;
import com.abhishek.finsight.core.Txn;

/** All details for one account: latest figures, transactions and the messages they came from. */
public class AccountActivity extends LockedActivity {
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("Account");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void render() {
        Aggregator.Result r = Engine.last;
        if (r == null) {
            setContentView(Ui.text(this, "Loading…", 14, Ui.MUTED, false));
            new Thread(() -> {
                Aggregator.Result res = Engine.build(this);
                ui.post(() -> show(res));
            }).start();
        } else {
            show(r);
        }
    }

    private void show(Aggregator.Result r) {
        String key = getIntent().getStringExtra("key");
        Account a = null;
        for (Account x : r.accounts) if (x.key().equals(key)) a = x;
        LinearLayout root = Ui.vbox(this);
        if (a == null) {
            root.addView(Ui.text(this, "This account is no longer in the list.", 14, Ui.MUTED, false));
            setContentView(Ui.page(this, root));
            return;
        }
        setTitle(a.label());

        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this, a.label(), 17, Ui.INK, true));
        c.addView(Ui.text(this, typeName(a.type) + " · " + a.messageCount + " messages · last seen " + Ui.when(a.lastSeen), 12, Ui.MUTED, false));
        c.addView(Ui.divider(this));
        val(c, "Balance", a.balance, true, a.balance.v != null && a.balance.v < 0 ? Ui.RED : Ui.GREEN);
        val(c, a.duePaid() ? "Last bill (paid)" : "Total amount due", a.totalDue, false, a.duePaid() ? Ui.GREEN : Ui.RED);
        val(c, "Minimum due", a.minDue, false, Ui.INK);
        if (a.dueDate.v != null) c.addView(Ui.row(this, "Due date", a.dueDate.v, Ui.INK));
        val(c, "Credit limit", a.creditLimit, false, Ui.INK);
        val(c, "Available limit", a.availableLimit, true, Ui.INK);
        val(c, "Last payment", a.lastPayment, false, Ui.GREEN);
        val(c, "EMI", a.emi, false, Ui.INK);
        val(c, "Outstanding", a.outstanding, false, Ui.AMBER);
        if (a.hasCurrentOverdue()) val(c, "Overdue", a.overdue, false, Ui.RED);
        val(c, "Deposit amount", a.depositAmount, false, Ui.GREEN);
        val(c, "Maturity value", a.maturityAmount, false, Ui.INK);
        if (a.maturityDate.v != null) c.addView(Ui.row(this, "Maturity date", a.maturityDate.v, Ui.INK));
        root.addView(c);

        if (!a.txns.isEmpty()) {
            root.addView(Ui.heading(this, "Recent transactions"));
            LinearLayout t = Ui.card(this);
            boolean firstRow = true;
            for (Txn x : a.txns) {
                if (!firstRow) t.addView(Ui.divider(this));
                firstRow = false;
                t.addView(Ui.row(this, Ui.when(x.time) + " · " + x.source, (x.credit ? "+ " : "− ") + Money.inr(x.amount), x.credit ? Ui.GREEN : Ui.INK));
                t.addView(Ui.text(this, x.desc, 12, Ui.MUTED, false));
            }
            root.addView(t);
        }

        root.addView(Ui.heading(this, "Messages used"));
        for (Account.Msg m : a.messages) {
            LinearLayout mc = Ui.card(this);
            mc.addView(Ui.text(this, m.source + " · " + m.sender + " · " + Ui.when(m.time), 11, Ui.MUTED, false));
            TextView body = Ui.text(this, m.text, 13, Ui.INK, false);
            body.setTextIsSelectable(true);
            mc.addView(body);
            root.addView(mc);
        }
        setContentView(Ui.page(this, root));
    }

    private void val(LinearLayout c, String label, Account.Val v, boolean withTime, int color) {
        if (v.v == null) return;
        String l = label + "\n" + (withTime ? Ui.when(v.t) : Ui.day(v.t));
        c.addView(Ui.row(this, l, Money.inr(v.v), color));
    }

    private static String typeName(AccountType t) {
        switch (t) {
            case CREDIT_CARD: return "Credit card";
            case LOAN: return "Loan";
            case DEPOSIT: return "Deposit";
            default: return "Bank account";
        }
    }
}
