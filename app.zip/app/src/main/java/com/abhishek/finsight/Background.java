package com.abhishek.finsight;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import com.abhishek.finsight.core.Account;
import com.abhishek.finsight.core.AccountType;
import com.abhishek.finsight.core.Aggregator;
import com.abhishek.finsight.core.Dates;
import com.abhishek.finsight.core.Money;

import java.util.HashSet;
import java.util.Set;

/**
 * Background check every few hours, even when the app is closed:
 * fetches new Gmail bank e-mails, re-reads SMS and saved messages, rebuilds the dashboard,
 * and sends reminders for card bills and EMIs due soon.
 */
public class Background extends JobService {
    static final int JOB_ID = 4242;
    static final long EVERY_MS = 4 * 3600 * 1000L;
    private static final String CHANNEL_DUES = "dues";
    private static final String CHANNEL_INFO = "info";

    private volatile Thread worker;

    // ---------- settings ----------

    static boolean enabled(Context c) {
        return Store.prefs(c).getBoolean("bg_enabled", true);
    }

    static boolean remindersOn(Context c) {
        return Store.prefs(c).getBoolean("bg_reminders", true);
    }

    static void setEnabled(Context c, boolean on) {
        Store.prefs(c).edit().putBoolean("bg_enabled", on).apply();
        if (on) schedule(c, true); else cancel(c);
    }

    static void setReminders(Context c, boolean on) {
        Store.prefs(c).edit().putBoolean("bg_reminders", on).apply();
    }

    static long lastRun(Context c) {
        return Store.prefs(c).getLong("bg_last_run", 0);
    }

    // ---------- scheduling ----------

    /** Safe to call often: only (re)schedules when needed. */
    static void schedule(Context c, boolean force) {
        if (!enabled(c)) return;
        JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null) return;
        if (!force && js.getPendingJob(JOB_ID) != null) return;
        JobInfo job = new JobInfo.Builder(JOB_ID, new ComponentName(c, Background.class))
                .setPeriodic(EVERY_MS, 60 * 60 * 1000L)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setRequiresBatteryNotLow(true)
                .setPersisted(true)
                .build();
        js.schedule(job);
    }

    static void cancel(Context c) {
        JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js != null) js.cancel(JOB_ID);
    }

    // ---------- the job ----------

    @Override
    public boolean onStartJob(JobParameters params) {
        Thread t = new Thread(() -> {
            try {
                runCheck(getApplicationContext());
            } catch (Exception ignored) {
            }
            jobFinished(params, false);
        });
        worker = t;
        t.start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        Thread t = worker;
        if (t != null) t.interrupt();
        return true;
    }

    /** Also used by the "Check now" button. Runs on a background thread. */
    static void runCheck(Context c) {
        if (Gmail.signedIn(c)) {
            try {
                Gmail.sync(c, null);
            } catch (Exception e) {
                String msg = e.getMessage() == null ? "" : e.getMessage();
                if (msg.contains("sign in") || msg.contains("expired") || msg.contains("refused")) {
                    notifyOncePerDay(c, "gmail", "Gmail needs you to sign in again",
                            "Open FinSight → Sources → Gmail to reconnect.");
                }
            }
        }
        Aggregator.Result r = Engine.build(c);
        Store.prefs(c).edit().putLong("bg_last_run", System.currentTimeMillis()).apply();
        if (remindersOn(c)) remindDues(c, r);
    }

    private static void remindDues(Context c, Aggregator.Result r) {
        long now = System.currentTimeMillis();
        long day = 86400000L;
        Set<String> sent = new HashSet<>(Store.prefs(c).getStringSet("bg_sent", new HashSet<>()));
        boolean changed = false;
        for (Account a : r.accounts) {
            if (a.dueDate.v == null) continue;
            if (a.type != AccountType.CREDIT_CARD && a.type != AccountType.LOAN) continue;
            if (a.type == AccountType.CREDIT_CARD && a.duePaid()) continue;
            long due = Dates.parse(a.dueDate.v);
            if (due < 0) continue;
            long daysLeft = (due - startOfToday()) / day;
            if (daysLeft < 0 || daysLeft > 3) continue;
            // one reminder 3 days before (or as soon as seen) and one on the day itself
            String stage = daysLeft == 0 ? "today" : "soon";
            String tag = a.key() + "|" + a.dueDate.v + "|" + stage;
            if (sent.contains(tag)) continue;
            Double amt = a.type == AccountType.CREDIT_CARD ? a.totalDue.v : a.emi.v;
            String what = a.type == AccountType.CREDIT_CARD ? "Card bill" : "EMI";
            String when = daysLeft == 0 ? "due today" : daysLeft == 1 ? "due tomorrow" : "due in " + daysLeft + " days";
            String title = what + " " + when + (amt == null ? "" : ": " + Money.inr(amt));
            String text = a.label() + " · due " + Ui.day(due)
                    + (a.type == AccountType.CREDIT_CARD && a.minDue.v != null ? " · min " + Money.inr(a.minDue.v) : "");
            notifyNow(c, CHANNEL_DUES, Math.abs(tag.hashCode()), title, text);
            sent.add(tag);
            changed = true;
        }
        if (changed) {
            // forget reminders older than ~2 months so the set stays small
            if (sent.size() > 200) sent.clear();
            Store.prefs(c).edit().putStringSet("bg_sent", sent).apply();
        }
    }

    private static long startOfToday() {
        return java.time.LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli();
    }

    // ---------- notifications ----------

    static boolean canNotify(Context c) {
        return Build.VERSION.SDK_INT < 33
                || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private static void channels(NotificationManager nm) {
        NotificationChannel d = new NotificationChannel(CHANNEL_DUES, "Due reminders", NotificationManager.IMPORTANCE_HIGH);
        d.setDescription("Credit card bills and EMIs due in the next 3 days");
        nm.createNotificationChannel(d);
        NotificationChannel i = new NotificationChannel(CHANNEL_INFO, "App notices", NotificationManager.IMPORTANCE_DEFAULT);
        i.setDescription("For example when Gmail needs you to sign in again");
        nm.createNotificationChannel(i);
    }

    private static void notifyOncePerDay(Context c, String key, String title, String text) {
        String k = "bg_notice_" + key;
        long last = Store.prefs(c).getLong(k, 0);
        if (System.currentTimeMillis() - last < 20 * 3600 * 1000L) return;
        Store.prefs(c).edit().putLong(k, System.currentTimeMillis()).apply();
        notifyNow(c, CHANNEL_INFO, key.hashCode(), title, text);
    }

    private static void notifyNow(Context c, String channel, int id, String title, String text) {
        if (!canNotify(c)) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        channels(nm);
        Intent open = new Intent(c, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(c, channel)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        nm.notify(id, n);
    }
}
