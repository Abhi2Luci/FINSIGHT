package com.abhishek.finsight.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Combines updates from all messages into one list of accounts plus totals. */
public final class Aggregator {
    private Aggregator() {}

    public static class Result {
        public final List<Account> accounts = new ArrayList<>();
        public double bankBalance;
        public int bankWithBalance;
        public double cardDue;
        public double cardLimit;
        public double cardAvailable;
        public double loanOutstanding;
        public double monthlyEmi;
        public double deposits;
        public int messagesRead;
        public int messagesUsed;

        public List<Account> of(AccountType t) {
            List<Account> l = new ArrayList<>();
            for (Account a : accounts) if (a.type == t) l.add(a);
            return l;
        }
    }

    public static Result build(List<RawMessage> messages) {
        List<Update> ups = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        int used = 0;
        for (RawMessage m : messages) {
            // the same alert often arrives by SMS, e-mail and notification: count it once per source text
            String k = m.text.trim();
            if (k.length() > 200) k = k.substring(0, 200);
            if (!seen.add(k + "|" + (m.time / 120000L))) continue;
            List<Update> u = Parser.parse(m);
            if (!u.isEmpty()) used++;
            ups.addAll(u);
        }
        Result r = aggregate(ups);
        r.messagesRead = messages.size();
        r.messagesUsed = used;
        return r;
    }

    public static Result aggregate(List<Update> ups) {
        ups.sort((a, b) -> Long.compare(a.time, b.time));

        // "Spent on HDFC Bank Card 7788" looks like a debit card until we know 7788 is a credit card
        Set<String> creditCards = new HashSet<>();
        for (Update u : ups) {
            if (u.type == AccountType.CREDIT_CARD && !u.last4.isEmpty()) creditCards.add(u.last4);
        }
        for (Update u : ups) {
            if (u.viaDebitCard && creditCards.contains(u.last4)) {
                u.type = AccountType.CREDIT_CARD;
                u.viaDebitCard = false;
                if (u.balance != null) {
                    if (u.availableLimit == null && u.balance > 0) u.availableLimit = u.balance;
                    u.balance = null;
                }
            }
        }

        // banks seen for each type + number, so alerts that do not name the bank can join the right account
        Map<String, Set<String>> banksFor = new HashMap<>();
        for (Update u : ups) {
            if (u.last4.isEmpty() || Banks.UNKNOWN.equals(u.bank)) continue;
            banksFor.computeIfAbsent(u.type + "|" + u.last4, k -> new HashSet<>()).add(u.bank);
        }

        Map<String, Account> map = new LinkedHashMap<>();
        List<Update> noNumber = new ArrayList<>();
        for (Update u : ups) {
            if (u.last4.isEmpty()) { noNumber.add(u); continue; }
            String bank = u.bank;
            if (Banks.UNKNOWN.equals(bank)) {
                Set<String> b = banksFor.get(u.type + "|" + u.last4);
                if (b != null && b.size() == 1) bank = b.iterator().next();
            }
            u.bank = bank;
            account(map, u).apply(u);
        }

        // messages without an account number: attach to the single matching account of that bank, if there is one
        for (Update u : noNumber) {
            Account match = null;
            int count = 0;
            for (Account a : map.values()) {
                if (a.type == u.type && a.bank.equals(u.bank) && !a.last4.isEmpty()) { match = a; count++; }
            }
            if (count == 1) match.apply(u);
            else account(map, u).apply(u);
        }

        Result r = new Result();
        for (Account a : map.values()) {
            a.trim();
            boolean useful = a.balance.v != null || a.totalDue.v != null || a.minDue.v != null
                    || a.creditLimit.v != null || a.availableLimit.v != null || a.emi.v != null
                    || a.outstanding.v != null || a.depositAmount.v != null || a.maturityAmount.v != null
                    || a.dueDate.v != null || !a.txns.isEmpty();
            if (useful) r.accounts.add(a);
        }
        r.accounts.sort((a, b) -> {
            int c = Integer.compare(a.type.ordinal(), b.type.ordinal());
            if (c != 0) return c;
            return Long.compare(b.lastSeen, a.lastSeen);
        });

        for (Account a : r.accounts) {
            switch (a.type) {
                case SAVINGS:
                    if (a.balance.v != null) { r.bankBalance += a.balance.v; r.bankWithBalance++; }
                    break;
                case CREDIT_CARD:
                    if (a.totalDue.v != null && !a.duePaid()) r.cardDue += a.totalDue.v;
                    if (a.creditLimit.v != null) r.cardLimit += a.creditLimit.v;
                    if (a.availableLimit.v != null) r.cardAvailable += a.availableLimit.v;
                    break;
                case LOAN:
                    if (a.outstanding.v != null) r.loanOutstanding += a.outstanding.v;
                    if (a.emi.v != null) r.monthlyEmi += a.emi.v;
                    break;
                case DEPOSIT:
                    if (a.depositAmount.v != null) r.deposits += a.depositAmount.v;
                    else if (a.maturityAmount.v != null) r.deposits += a.maturityAmount.v;
                    break;
                default:
                    break;
            }
        }
        return r;
    }

    private static Account account(Map<String, Account> map, Update u) {
        String key = u.type + "|" + u.bank + "|" + u.last4;
        Account a = map.get(key);
        if (a == null) {
            a = new Account();
            a.type = u.type;
            a.bank = u.bank;
            a.last4 = u.last4;
            map.put(key, a);
        }
        return a;
    }
}
