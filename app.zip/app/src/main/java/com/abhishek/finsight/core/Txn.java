package com.abhishek.finsight.core;

/** A debit or credit seen in a message. */
public class Txn {
    public final long time;
    public final double amount;
    public final boolean credit;
    public final String desc;
    public final String source;

    public Txn(long time, double amount, boolean credit, String desc, String source) {
        this.time = time;
        this.amount = amount;
        this.credit = credit;
        this.desc = desc;
        this.source = source;
    }
}
