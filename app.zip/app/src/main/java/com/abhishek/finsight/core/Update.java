package com.abhishek.finsight.core;

/** Everything one message says about one account. Null fields were not mentioned. */
public class Update {
    public AccountType type;
    public String bank;
    public String last4;      // "" when the message names no account number
    public boolean viaDebitCard;
    public long time;
    public String source;
    public String sender;
    public String text;

    public Double balance;
    public Double totalDue;
    public Double minDue;
    public Double creditLimit;
    public Double availableLimit;
    public Double lastPayment;
    public Double emi;
    public Double outstanding;
    public Double overdue;
    public Double depositAmount;
    public Double maturityAmount;
    public String dueDate;
    public String maturityDate;
    public Txn txn;

    public boolean hasData() {
        return balance != null || totalDue != null || minDue != null || creditLimit != null
                || availableLimit != null || lastPayment != null || emi != null || outstanding != null
                || overdue != null || depositAmount != null || maturityAmount != null
                || dueDate != null || maturityDate != null || txn != null;
    }
}
