package com.abhishek.finsight;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Small helpers so every screen can be built in code (no layout files). */
final class Ui {
    private Ui() {}

    static final int BG = Color.parseColor("#F3F5F9");
    static final int CARD = Color.WHITE;
    static final int INK = Color.parseColor("#1B2430");
    static final int MUTED = Color.parseColor("#667085");
    static final int PRIMARY = Color.parseColor("#0B5CAD");
    static final int GREEN = Color.parseColor("#12805C");
    static final int RED = Color.parseColor("#C0362C");
    static final int AMBER = Color.parseColor("#B25E09");
    static final int LINE = Color.parseColor("#E4E7EC");

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static ScrollView page(Activity a, LinearLayout content) {
        ScrollView sv = new ScrollView(a);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        int p = dp(a, 14);
        content.setPadding(p, p, p, dp(a, 40));
        sv.addView(content, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return sv;
    }

    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static GradientDrawable rounded(int color, float radiusPx, int strokeColor, int strokePx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        if (strokePx > 0) g.setStroke(strokePx, strokeColor);
        return g;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = vbox(c);
        l.setBackground(rounded(CARD, dp(c, 14), LINE, dp(c, 1)));
        int p = dp(c, 14);
        l.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(c, 10);
        l.setLayoutParams(lp);
        return l;
    }

    static TextView text(Context c, CharSequence s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLineSpacing(0, 1.1f);
        return t;
    }

    static TextView heading(Context c, String s) {
        TextView t = text(c, s, 15, INK, true);
        t.setPadding(dp(c, 4), dp(c, 16), 0, dp(c, 8));
        return t;
    }

    static Button button(Context c, String label, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackground(rounded(PRIMARY, dp(c, 10), 0, 0));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 46));
        lp.topMargin = dp(c, 8);
        b.setLayoutParams(lp);
        return b;
    }

    static Button secondaryButton(Context c, String label, View.OnClickListener l) {
        Button b = button(c, label, l);
        b.setTextColor(PRIMARY);
        b.setBackground(rounded(Color.WHITE, dp(c, 10), PRIMARY, dp(c, 1)));
        return b;
    }

    static EditText input(Context c, String hint, String value, boolean multiline) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setText(value);
        e.setTextSize(14);
        e.setTextColor(INK);
        if (multiline) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            e.setMinLines(4);
            e.setGravity(Gravity.TOP | Gravity.START);
        } else {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            e.setSingleLine(true);
        }
        return e;
    }

    static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(LINE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(c, 1)));
        lp.topMargin = dp(c, 8);
        lp.bottomMargin = dp(c, 8);
        v.setLayoutParams(lp);
        return v;
    }

    /** Label on the left, value on the right. */
    static LinearLayout row(Context c, String label, String value, int valueColor) {
        LinearLayout r = hbox(c);
        r.setPadding(0, dp(c, 3), 0, dp(c, 3));
        TextView l = text(c, label, 13, MUTED, false);
        TextView v = text(c, value, 13, valueColor, true);
        v.setGravity(Gravity.END);
        r.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.addView(v, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return r;
    }

    static String when(long t) {
        if (t <= 0) return "";
        return new SimpleDateFormat("d MMM yyyy, h:mm a", Locale.ENGLISH).format(new Date(t));
    }

    static String day(long t) {
        if (t <= 0) return "";
        return new SimpleDateFormat("d MMM yyyy", Locale.ENGLISH).format(new Date(t));
    }

    static void toast(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_LONG).show();
    }
}
