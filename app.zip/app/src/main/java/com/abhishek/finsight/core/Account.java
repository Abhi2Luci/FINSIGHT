package com.abhishek.finsight.core;

import java.util.ArrayList;
import java.util.List;

/** One account, card, loan or deposit with the latest known figures. */
public class Account {

    /** A value plus the time of the message it came from; newer messages win. */
    public static class Val {
        public Double v;
        public long t;

        void set(Double nv, long nt) {
            if (nv != null && (v == null || nt >= t)) { v = nv; t = nt; }
        }
    }

    public static class StrVal {
        public String v;
        public long t;

        void set(String nv, long nt) {
            if (nv != null && (v == null || nt >= t)) { v = nv; t = nt; }
        }
    }

    public static class Msg {
        public final long time;
        public final String source;
        public final String sender;
        public final String text;

        Msg(long time, String source, String sender, String text) {
            this.time = time;
            this.source = source;
            this.sender = sender;
            this.text = text;
        }
    }

    public AccountType type;
    public String bank;
    public String last4;
    public boolean viaDebitCard;
    public long lastSeen;
    public int messageCount;

    public final Val balance = new Val();
    public final Val totalDue = new Val();
    public final Val minDue = new Val();
    public final Val creditLimit = new Val();
    public final Val availableLimit = new Val();
    public final Val lastPayment = new Val();
    public final Val emi = new Val();
    public final Val outstanding = new Val();
    public final Val overdue = new Val();
    public final Val depositAmount = new Val();
    public final Val maturityAmount = new Val();
    public final StrVal dueDate = new StrVal();
    public final StrVal maturityDate = new StrVal();

    public final List<Txn> txns = new ArrayList<>();
    public final List<Msg> messages = new ArrayList<>();

    public String key() {
        return type + "|" + bank + "|" + last4;
    }

    public String label() {
        String num = last4 == null || last4.isEmpty() ? "" : (viaDebitCard ? " · debit card ••" : " ••") + last4;
        return bank + num;
    }

    public void apply(Update u) {
        lastSeen = Math.max(lastSeen, u.time);
        messageCount++;
        if (u.viaDebitCard) viaDebitCard = true;
        balance.set(u.balance, u.time);
        totalDue.set(u.totalDue, u.time);
        minDue.set(u.minDue, u.time);
        creditLimit.set(u.creditLimit, u.time);
        availableLimit.set(u.availableLimit, u.time);
        lastPayment.set(u.lastPayment, u.time);
        emi.set(u.emi, u.time);
        outstanding.set(u.outstanding, u.time);
        overdue.set(u.overdue, u.time);
        depositAmount.set(u.depositAmount, u.time);
        maturityAmount.set(u.maturityAmount, u.time);
        dueDate.set(u.dueDate, u.time);
        maturityDate.set(u.maturityDate, u.time);
        if (u.txn != null) txns.add(u.txn);
        messages.add(new Msg(u.time, u.source, u.sender, u.text));
    }

    /** Card bill paid after the latest statement. */
    public boolean duePaid() {
        return totalDue.v != null && lastPayment.v != null && lastPayment.t > totalDue.t
                && lastPayment.v >= totalDue.v * 0.99;
    }

    /** Overdue figure is stale once a newer message without it arrived (e.g. after payment). */
    public boolean hasCurrentOverdue() {
        return overdue.v != null && overdue.v > 0 && overdue.t >= lastSeen - 45L * 24 * 3600 * 1000;
    }

    void trim() {
        txns.sort((a, b) -> Long.compare(b.time, a.time));
        while (txns.size() > 40) txns.remove(txns.size() - 1);
        messages.sort((a, b) -> Long.compare(b.time, a.time));
        while (messages.size() > 15) messages.remove(messages.size() - 1);
    }
}
