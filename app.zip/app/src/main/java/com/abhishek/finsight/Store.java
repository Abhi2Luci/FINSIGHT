package com.abhishek.finsight;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.abhishek.finsight.core.Parser;
import com.abhishek.finsight.core.RawMessage;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Keeps financial messages from Gmail, notifications and imports on the phone.
 * SMS are not copied: they are read fresh from the inbox each time.
 * Only messages the parser recognises as financial are saved.
 */
final class Store extends SQLiteOpenHelper {
    private static Store instance;

    static synchronized Store get(Context c) {
        if (instance == null) instance = new Store(c.getApplicationContext());
        return instance;
    }

    static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("finsight", Context.MODE_PRIVATE);
    }

    private final SharedPreferences prefs;

    private Store(Context c) {
        super(c, "finsight.db", null, 1);
        prefs = prefs(c);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE msgs (k TEXT PRIMARY KEY, source TEXT, sender TEXT, time INTEGER, body TEXT)");
        db.execSQL("CREATE INDEX msgs_source ON msgs(source)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
    }

    /** Saves the financial ones. @return {financial messages found, newly saved} */
    int[] saveFinancial(List<RawMessage> list) {
        int financial = 0, added = 0;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            for (RawMessage m : list) {
                if (Parser.parse(m).isEmpty()) continue;
                financial++;
                ContentValues v = new ContentValues();
                v.put("k", m.key());
                v.put("source", m.source);
                v.put("sender", m.sender);
                v.put("time", m.time);
                v.put("body", m.text);
                long id = db.insertWithOnConflict("msgs", null, v, SQLiteDatabase.CONFLICT_IGNORE);
                if (id != -1) added++;
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        if (added > 0) markDirty();
        return new int[]{financial, added};
    }

    /** Tells the dashboard to rebuild next time it is shown. */
    void markDirty() {
        prefs.edit().putLong("dirty", System.currentTimeMillis()).apply();
    }

    List<RawMessage> all() {
        List<RawMessage> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT source, sender, time, body FROM msgs ORDER BY time", null);
        try {
            while (c.moveToNext()) out.add(new RawMessage(c.getString(0), c.getString(1), c.getLong(2), c.getString(3)));
        } finally {
            c.close();
        }
        return out;
    }

    Map<String, Integer> countsBySource() {
        Map<String, Integer> m = new LinkedHashMap<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT source, COUNT(*) FROM msgs GROUP BY source ORDER BY source", null);
        try {
            while (c.moveToNext()) m.put(c.getString(0), c.getInt(1));
        } finally {
            c.close();
        }
        return m;
    }

    void deleteSource(String source) {
        getWritableDatabase().delete("msgs", "source = ?", new String[]{source});
        markDirty();
    }

    void deleteAll() {
        getWritableDatabase().delete("msgs", null, null);
        markDirty();
    }
}
