package com.abhishek.finsight;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import com.abhishek.finsight.core.RawMessage;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Read-only Gmail access with your own Google Cloud "Desktop app" OAuth client.
 * Sign-in happens in the browser; Google sends the code back to a tiny server on 127.0.0.1
 * inside this app. If that hand-back fails, the address from the browser can be pasted instead.
 */
final class Gmail {
    private Gmail() {}

    interface Done {
        void done(String error);
    }

    interface Progress {
        void progress(String status);
    }

    private static final String SCOPE = "https://www.googleapis.com/auth/gmail.readonly";
    private static final String AUTH = "https://accounts.google.com/o/oauth2/v2/auth";
    private static final String TOKEN = "https://oauth2.googleapis.com/token";
    private static final String API = "https://gmail.googleapis.com/gmail/v1/users/me/";

    static final String QUERY = "(\"a/c\" OR account OR acct OR \"credit card\" OR balance OR loan OR EMI OR debited OR credited"
            + " OR statement OR \"amount due\" OR \"fixed deposit\" OR spent) -category:promotions -category:social";

    private static volatile ServerSocket server;

    // ---------- settings ----------

    static String clientId(Context c) { return Store.prefs(c).getString("g_client_id", ""); }

    static String clientSecret(Context c) { return Store.prefs(c).getString("g_client_secret", ""); }

    static String email(Context c) { return Store.prefs(c).getString("g_email", ""); }

    static long lastSync(Context c) { return Store.prefs(c).getLong("g_last_sync_ms", 0); }

    static boolean signedIn(Context c) { return !Store.prefs(c).getString("g_refresh", "").isEmpty(); }

    static void saveClient(Context c, String id, String secret) {
        Store.prefs(c).edit().putString("g_client_id", id.trim()).putString("g_client_secret", secret.trim()).apply();
    }

    static void signOut(Context c) {
        String refresh = Store.prefs(c).getString("g_refresh", "");
        Store.prefs(c).edit().remove("g_refresh").remove("g_access").remove("g_expiry").remove("g_email")
                .remove("g_last_sync_ms").apply();
        if (!refresh.isEmpty()) {
            new Thread(() -> {
                try {
                    post("https://oauth2.googleapis.com/revoke", "token=" + enc(refresh));
                } catch (Exception ignored) {
                }
            }).start();
        }
    }

    // ---------- sign-in ----------

    static void startSignIn(Context ctx, Done done) {
        Context c = ctx.getApplicationContext();
        Handler ui = new Handler(Looper.getMainLooper());
        String id = clientId(c);
        if (id.isEmpty() || clientSecret(c).isEmpty()) {
            done.done("Enter the Client ID and Client secret first.");
            return;
        }
        new Thread(() -> {
            ServerSocket ss;
            String state;
            String url;
            try {
                closeServer();
                ss = new ServerSocket(0, 5, InetAddress.getByName("127.0.0.1"));
                server = ss;
                String redirect = "http://127.0.0.1:" + ss.getLocalPort();
                String verifier = random(48);
                state = random(16);
                Store.prefs(c).edit().putString("g_verifier", verifier).putString("g_state", state)
                        .putString("g_redirect", redirect).apply();
                url = AUTH + "?client_id=" + enc(id)
                        + "&redirect_uri=" + enc(redirect)
                        + "&response_type=code"
                        + "&scope=" + enc(SCOPE)
                        + "&code_challenge=" + challenge(verifier)
                        + "&code_challenge_method=S256"
                        + "&access_type=offline&prompt=consent"
                        + "&state=" + state;
            } catch (Exception e) {
                ui.post(() -> done.done("Could not start sign-in: " + e.getMessage()));
                return;
            }
            final String openUrl = url;
            ui.post(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(openUrl));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    ctx.startActivity(i);
                } catch (Exception e) {
                    closeServer();
                    done.done("No browser found to sign in with.");
                }
            });
            String err = listen(c, ss, state);
            if (err != null && err.isEmpty()) return; // cancelled quietly (e.g. finished with a pasted address)
            ui.post(() -> done.done(err));
        }).start();
    }

    static void closeServer() {
        ServerSocket s = server;
        server = null;
        if (s != null) {
            try { s.close(); } catch (Exception ignored) { }
        }
    }

    /** Waits for Google to redirect the browser back. Returns null on success, "" if cancelled, or an error. */
    private static String listen(Context c, ServerSocket ss, String state) {
        long deadline = System.currentTimeMillis() + 10 * 60 * 1000L;
        try {
            while (System.currentTimeMillis() < deadline) {
                ss.setSoTimeout((int) Math.max(1000, deadline - System.currentTimeMillis()));
                Socket s;
                try {
                    s = ss.accept();
                } catch (SocketTimeoutException te) {
                    break;
                }
                try {
                    s.setSoTimeout(5000);
                    BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                    String line = r.readLine();
                    if (line == null || !line.startsWith("GET ")) { s.close(); continue; }
                    String path = line.split(" ")[1];
                    Map<String, String> q = query(path);
                    if (!q.containsKey("code") && !q.containsKey("error")) {
                        respond(s, 404, "Not found");
                        continue;
                    }
                    if (q.containsKey("error")) {
                        respond(s, 200, page("Sign-in was cancelled", "You can go back to FinSight."));
                        return "Google sign-in was cancelled (" + q.get("error") + ").";
                    }
                    if (!state.equals(q.get("state"))) {
                        respond(s, 400, page("Something went wrong", "Please start the sign-in again from FinSight."));
                        return "Sign-in check failed. Please try again.";
                    }
                    String err = exchange(c, q.get("code"));
                    respond(s, 200, err == null
                            ? page("Gmail connected", "FinSight can now read your bank e-mails.")
                            : page("Sign-in failed", err));
                    return err;
                } catch (SocketTimeoutException te) {
                    try { s.close(); } catch (Exception ignored) { }
                }
            }
            return "Sign-in timed out. Please try again.";
        } catch (Exception e) {
            return server == null ? "" : "Sign-in failed: " + e.getMessage();
        } finally {
            try { ss.close(); } catch (Exception ignored) { }
            if (server == ss) server = null;
        }
    }

    private static String page(String title, String body) {
        return "<!doctype html><html><head><meta name=viewport content='width=device-width,initial-scale=1'>"
                + "<title>FinSight</title></head><body style='font-family:sans-serif;padding:32px;text-align:center'>"
                + "<h2>" + title + "</h2><p>" + body + "</p>"
                + "<p><a style='display:inline-block;padding:14px 22px;background:#0B5CAD;color:#fff;border-radius:10px;text-decoration:none'"
                + " href='intent://open#Intent;scheme=finsight;package=com.abhishek.finsight;end'>Return to FinSight</a></p>"
                + "</body></html>";
    }

    private static void respond(Socket s, int code, String html) {
        try {
            byte[] b = html.getBytes(StandardCharsets.UTF_8);
            OutputStream o = s.getOutputStream();
            String head = "HTTP/1.1 " + code + " OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " + b.length
                    + "\r\nConnection: close\r\n\r\n";
            o.write(head.getBytes(StandardCharsets.UTF_8));
            o.write(b);
            o.flush();
            s.close();
        } catch (Exception ignored) {
        }
    }

    /** Fallback: user pastes the 127.0.0.1 address shown in the browser. Runs on a background thread. */
    static String finishWithPastedUrl(Context c, String pasted) {
        String p = pasted.trim();
        int qi = p.indexOf('?');
        if (qi < 0) return "That address has no sign-in code. Copy the full address starting with http://127.0.0.1";
        Map<String, String> q = query(p.substring(qi));
        if (q.containsKey("error")) return "Google sign-in was cancelled (" + q.get("error") + ").";
        String code = q.get("code");
        if (code == null) return "No code found in that address.";
        String state = Store.prefs(c).getString("g_state", "");
        if (!state.isEmpty() && q.containsKey("state") && !state.equals(q.get("state")))
            return "That address is from an older sign-in. Please sign in again.";
        closeServer();
        return exchange(c, code);
    }

    private static String exchange(Context c, String code) {
        try {
            SharedPreferences p = Store.prefs(c);
            String body = "code=" + enc(code)
                    + "&client_id=" + enc(clientId(c))
                    + "&client_secret=" + enc(clientSecret(c))
                    + "&redirect_uri=" + enc(p.getString("g_redirect", ""))
                    + "&grant_type=authorization_code"
                    + "&code_verifier=" + enc(p.getString("g_verifier", ""));
            JSONObject j = new JSONObject(post(TOKEN, body));
            if (j.has("error")) return "Google said: " + j.optString("error_description", j.optString("error"));
            String refresh = j.optString("refresh_token", "");
            if (refresh.isEmpty()) return "Google did not give long-term access. Remove FinSight at myaccount.google.com → Security → Third-party access, then sign in again.";
            p.edit().putString("g_refresh", refresh)
                    .putString("g_access", j.getString("access_token"))
                    .putLong("g_expiry", System.currentTimeMillis() + j.optLong("expires_in", 3600) * 1000L - 60000L)
                    .apply();
            try {
                JSONObject prof = new JSONObject(get(API + "profile", j.getString("access_token")));
                p.edit().putString("g_email", prof.optString("emailAddress", "")).apply();
            } catch (Exception ignored) {
            }
            return null;
        } catch (Exception e) {
            return "Sign-in failed: " + e.getMessage();
        }
    }

    private static String accessToken(Context c) throws Exception {
        SharedPreferences p = Store.prefs(c);
        String access = p.getString("g_access", "");
        if (!access.isEmpty() && System.currentTimeMillis() < p.getLong("g_expiry", 0)) return access;
        String refresh = p.getString("g_refresh", "");
        if (refresh.isEmpty()) throw new Exception("Gmail is not connected.");
        String body = "refresh_token=" + enc(refresh) + "&client_id=" + enc(clientId(c))
                + "&client_secret=" + enc(clientSecret(c)) + "&grant_type=refresh_token";
        JSONObject j = new JSONObject(post(TOKEN, body));
        if (j.has("error")) {
            if ("invalid_grant".equals(j.optString("error"))) {
                p.edit().remove("g_refresh").remove("g_access").apply();
                throw new Exception("Gmail access expired. Open Sources and sign in to Gmail again.");
            }
            throw new Exception("Gmail: " + j.optString("error_description", j.optString("error")));
        }
        access = j.getString("access_token");
        p.edit().putString("g_access", access)
                .putLong("g_expiry", System.currentTimeMillis() + j.optLong("expires_in", 3600) * 1000L - 60000L).apply();
        return access;
    }

    // ---------- sync ----------

    /** Fetches new bank e-mails and stores the financial ones. Runs on a background thread. @return status text */
    static String sync(Context c, Progress progress) throws Exception {
        String token = accessToken(c);
        long last = lastSync(c);
        boolean first = last == 0;
        String q = QUERY + (first ? " newer_than:730d" : " after:" + (last / 1000 - 2 * 86400));
        int cap = first ? 2500 : 800;

        List<String> ids = new ArrayList<>();
        String pageToken = null;
        do {
            String url = API + "messages?maxResults=500&q=" + enc(q) + (pageToken == null ? "" : "&pageToken=" + enc(pageToken));
            JSONObject j = new JSONObject(get(url, token));
            JSONArray arr = j.optJSONArray("messages");
            if (arr != null) for (int i = 0; i < arr.length(); i++) ids.add(arr.getJSONObject(i).getString("id"));
            pageToken = j.optString("nextPageToken", "");
            if (pageToken.isEmpty()) pageToken = null;
            if (progress != null) progress.progress("Finding bank e-mails… " + ids.size());
        } while (pageToken != null && ids.size() < cap);
        if (ids.size() > cap) ids = ids.subList(0, cap);

        final String tok = token;
        ExecutorService pool = Executors.newFixedThreadPool(6);
        List<Future<RawMessage>> futures = new ArrayList<>();
        for (String id : ids) futures.add(pool.submit(() -> fetch(id, tok)));
        List<RawMessage> got = Collections.synchronizedList(new ArrayList<>());
        int done = 0, failed = 0;
        for (Future<RawMessage> f : futures) {
            try {
                RawMessage m = f.get();
                if (m != null) got.add(m);
            } catch (Exception e) {
                failed++;
            }
            done++;
            if (progress != null && done % 20 == 0) progress.progress("Reading e-mails… " + done + " of " + ids.size());
        }
        pool.shutdown();
        if (failed > 0 && got.isEmpty()) throw new Exception("Could not read e-mails from Gmail. Check your internet and try again.");

        int[] r = Store.get(c).saveFinancial(got);
        Store.prefs(c).edit().putLong("g_last_sync_ms", System.currentTimeMillis()).apply();
        return "Gmail: checked " + ids.size() + " e-mails, " + r[0] + " with financial details (" + r[1] + " new).";
    }

    private static RawMessage fetch(String id, String token) throws Exception {
        JSONObject j = new JSONObject(get(API + "messages/" + id + "?format=full", token));
        long time = j.optLong("internalDate", System.currentTimeMillis());
        JSONObject payload = j.optJSONObject("payload");
        if (payload == null) return null;
        String from = "", subject = "";
        JSONArray headers = payload.optJSONArray("headers");
        if (headers != null) {
            for (int i = 0; i < headers.length(); i++) {
                JSONObject h = headers.getJSONObject(i);
                String n = h.optString("name");
                if ("From".equalsIgnoreCase(n)) from = h.optString("value");
                if ("Subject".equalsIgnoreCase(n)) subject = h.optString("value");
            }
        }
        StringBuilder plain = new StringBuilder();
        StringBuilder html = new StringBuilder();
        collect(payload, plain, html);
        String body = plain.length() > 0 ? plain.toString() : stripHtml(html.toString());
        if (body.trim().isEmpty()) body = j.optString("snippet", "");
        String text = subject + "\n" + body;
        if (text.length() > 9000) text = text.substring(0, 9000);
        return new RawMessage("Gmail", from, time, text);
    }

    private static void collect(JSONObject part, StringBuilder plain, StringBuilder html) {
        String mime = part.optString("mimeType", "");
        JSONObject b = part.optJSONObject("body");
        String data = b == null ? "" : b.optString("data", "");
        if (!data.isEmpty()) {
            String s = decode(data);
            if (mime.startsWith("text/plain")) plain.append(s).append('\n');
            else if (mime.startsWith("text/html")) html.append(s).append('\n');
        }
        JSONArray parts = part.optJSONArray("parts");
        if (parts != null) {
            for (int i = 0; i < parts.length(); i++) {
                JSONObject p = parts.optJSONObject(i);
                if (p != null) collect(p, plain, html);
            }
        }
    }

    private static String decode(String b64url) {
        try {
            String s = b64url.replace('-', '+').replace('_', '/').replace("=", "");
            byte[] d = Base64.getMimeDecoder().decode(s);
            return new String(d, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    static String stripHtml(String h) {
        String s = h.replaceAll("(?is)<(style|script|head)[^>]*>.*?</\\1>", " ");
        s = s.replaceAll("(?i)<br\\s*/?>|</p>|</div>|</tr>|</h\\d>|</li>", "\n");
        s = s.replaceAll("(?i)</td>|</th>", " ");
        s = s.replaceAll("<[^>]+>", " ");
        s = s.replace("&nbsp;", " ").replace("&amp;", "&").replace("&#8377;", "₹").replace("&#x20b9;", "₹")
                .replace("&#X20B9;", "₹").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
                .replace("&#39;", "'").replace("&rsquo;", "'").replace("&#160;", " ");
        s = s.replaceAll("[ \\t\\x0B\\f]+", " ");
        s = s.replaceAll("\\s*\\n\\s*", "\n");
        return s.trim();
    }

    // ---------- http ----------

    private static String get(String url, String token) throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        h.setConnectTimeout(20000);
        h.setReadTimeout(30000);
        h.setRequestProperty("Authorization", "Bearer " + token);
        return read(h);
    }

    private static String post(String url, String form) throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        h.setConnectTimeout(20000);
        h.setReadTimeout(30000);
        h.setRequestMethod("POST");
        h.setDoOutput(true);
        h.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        OutputStream o = h.getOutputStream();
        o.write(form.getBytes(StandardCharsets.UTF_8));
        o.close();
        return read(h);
    }

    private static String read(HttpURLConnection h) throws Exception {
        int code = h.getResponseCode();
        InputStream in = code >= 400 ? h.getErrorStream() : h.getInputStream();
        String s = "";
        if (in != null) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            s = new String(bo.toByteArray(), StandardCharsets.UTF_8);
        }
        boolean tokenCall = h.getURL().toString().startsWith(TOKEN);
        h.disconnect();
        if (code < 400) return s;
        // the token endpoint answers errors as JSON {"error": "..."}; the caller explains them
        if (tokenCall && s.trim().startsWith("{")) return s;
        if (code == 401) throw new Exception("Gmail access was refused. Sign in to Gmail again.");
        if (s.contains("accessNotConfigured") || s.contains("SERVICE_DISABLED"))
            throw new Exception("The Gmail API is not enabled in your Google Cloud project (APIs & Services → Library → Gmail API → Enable).");
        try {
            JSONObject j = new JSONObject(s);
            Object e = j.opt("error");
            String msg = e instanceof JSONObject ? ((JSONObject) e).optString("message", "error") : String.valueOf(e);
            throw new Exception("Gmail: " + msg);
        } catch (org.json.JSONException je) {
            throw new Exception("Gmail error (HTTP " + code + ")");
        }
    }

    // ---------- small utils ----------

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    private static Map<String, String> query(String path) {
        Map<String, String> m = new LinkedHashMap<>();
        int qi = path.indexOf('?');
        if (qi < 0) return m;
        String qs = path.substring(qi + 1);
        int hash = qs.indexOf('#');
        if (hash >= 0) qs = qs.substring(0, hash);
        for (String kv : qs.split("&")) {
            int e = kv.indexOf('=');
            if (e <= 0) continue;
            try {
                m.put(URLDecoder.decode(kv.substring(0, e), "UTF-8"), URLDecoder.decode(kv.substring(e + 1), "UTF-8"));
            } catch (Exception ignored) {
            }
        }
        return m;
    }

    private static String random(int bytes) {
        byte[] b = new byte[bytes];
        new SecureRandom().nextBytes(b);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(b);
    }

    private static String challenge(String verifier) throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII));
        return Base64.getUrlEncoder().withoutPadding().encodeToString(d);
    }
}
