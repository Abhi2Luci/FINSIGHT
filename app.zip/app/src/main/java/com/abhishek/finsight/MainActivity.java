package com.abhishek.finsight;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.abhishek.finsight.core.Account;
import com.abhishek.finsight.core.AccountType;
import com.abhishek.finsight.core.Aggregator;
import com.abhishek.finsight.core.Dates;
import com.abhishek.finsight.core.Money;

import java.util.ArrayList;
import java.util.List;

/** Dashboard: totals, upcoming dues and every account found. */
public class MainActivity extends LockedActivity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean busy = false;
    private String status = "";
    private boolean unlockedOnce = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTitle("FinSight");
        Background.schedule(this, false);
    }

    /** Ask once, after unlocking, so reminders can be shown (Android 13+). */
    private void askNotificationsOnce() {
        if (android.os.Build.VERSION.SDK_INT >= 33 && !Background.canNotify(this)
                && !Store.prefs(this).getBoolean("asked_notify", false)) {
            Store.prefs(this).edit().putBoolean("asked_notify", true).apply();
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 21);
        }
    }

    @Override
    protected void render() {
        boolean first = !unlockedOnce;
        unlockedOnce = true;
        if (first) askNotificationsOnce();
        if (Engine.last == null || first || Engine.builtAt < Store.prefs(this).getLong("dirty", 0)) {
            refresh(first && shouldAutoSyncGmail());
        } else {
            show(Engine.last);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // new data arrived (import / sources screen) while we were away
        if (!busy && unlockedOnce && !Lock.needsUnlock(this) && Engine.last != null
                && Engine.builtAt < Store.prefs(this).getLong("dirty", 0)) {
            refresh(false);
        }
    }

    private boolean shouldAutoSyncGmail() {
        return Gmail.signedIn(this) && System.currentTimeMillis() - Gmail.lastSync(this) > 3 * 3600 * 1000L;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, "Refresh").setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        menu.add(0, 2, 1, "Sources").setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (Lock.needsUnlock(this)) return true;
        if (item.getItemId() == 1) {
            refresh(Gmail.signedIn(this));
            return true;
        }
        if (item.getItemId() == 2) {
            startActivity(new Intent(this, SourcesActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void refresh(boolean withGmail) {
        if (busy) return;
        busy = true;
        showLoading("Reading your messages…");
        new Thread(() -> {
            String note = "";
            if (withGmail) {
                try {
                    note = Gmail.sync(this, s -> ui.post(() -> showLoading(s)));
                } catch (Exception e) {
                    note = e.getMessage();
                }
            }
            ui.post(() -> showLoading("Combining accounts…"));
            Aggregator.Result r;
            try {
                r = Engine.build(this);
            } catch (Exception e) {
                r = Engine.last;
                note = "Could not read messages: " + e.getMessage();
            }
            final Aggregator.Result res = r;
            final String n = note;
            ui.post(() -> {
                busy = false;
                status = n == null ? "" : n;
                if (res != null) show(res);
            });
        }).start();
    }

    private void showLoading(String msg) {
        LinearLayout l = Ui.vbox(this);
        l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(Ui.BG);
        ProgressBar pb = new ProgressBar(this);
        l.addView(pb);
        TextView t = Ui.text(this, msg, 14, Ui.MUTED, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(this, 12), 0, 0);
        l.addView(t);
        setContentView(l);
    }

    private void show(Aggregator.Result r) {
        LinearLayout root = Ui.vbox(this);

        boolean smsOk = SmsReader.allowed(this);
        if (r.accounts.isEmpty()) {
            LinearLayout c = Ui.card(this);
            c.addView(Ui.text(this, "Let's find your accounts", 18, Ui.INK, true));
            c.addView(Ui.text(this, smsOk
                    ? "No bank details were found yet. Connect Gmail, turn on notification access for WhatsApp/Telegram, or import a chat export."
                    : "Allow SMS access so FinSight can read bank alerts. You can also connect Gmail and WhatsApp/Telegram.", 14, Ui.MUTED, false));
            c.addView(Ui.button(this, "Set up sources", v -> startActivity(new Intent(this, SourcesActivity.class))));
            root.addView(c);
        } else {
            addTotals(root, r);
            addUpcoming(root, r);
            for (AccountType t : new AccountType[]{AccountType.SAVINGS, AccountType.CREDIT_CARD, AccountType.LOAN, AccountType.DEPOSIT}) {
                List<Account> list = r.of(t);
                if (list.isEmpty()) continue;
                root.addView(Ui.heading(this, t.title + " (" + list.size() + ")"));
                for (Account a : list) root.addView(accountCard(a));
            }
        }

        StringBuilder foot = new StringBuilder();
        foot.append("Checked ").append(r.messagesRead).append(" messages · ").append(r.messagesUsed).append(" had financial details");
        if (!smsOk) foot.append("\nSMS access is off — tap Sources to allow it.");
        if (!status.isEmpty()) foot.append("\n").append(status);
        foot.append("\nFigures come from the latest message seen for each account and may be out of date. Everything stays on this phone.");
        TextView f = Ui.text(this, foot.toString(), 12, Ui.MUTED, false);
        f.setPadding(Ui.dp(this, 4), Ui.dp(this, 12), Ui.dp(this, 4), 0);
        root.addView(f);

        setContentView(Ui.page(this, root));
    }

    private void addTotals(LinearLayout root, Aggregator.Result r) {
        LinearLayout c = Ui.card(this);
        c.setBackground(Ui.rounded(Ui.PRIMARY, Ui.dp(this, 16), 0, 0));
        double net = r.bankBalance + r.deposits - r.cardDue - r.loanOutstanding;
        c.addView(Ui.text(this, "Net position (approx.)", 13, 0xCCFFFFFF, false));
        c.addView(Ui.text(this, Money.inr(net), 28, 0xFFFFFFFF, true));
        c.addView(Ui.text(this, "Bank balances + deposits − card dues − loans outstanding", 11, 0xB3FFFFFF, false));
        root.addView(c);

        List<String[]> tiles = new ArrayList<>();
        tiles.add(new String[]{"In bank accounts", Money.inr(r.bankBalance), r.bankWithBalance + " with balance"});
        tiles.add(new String[]{"Credit card dues", Money.inr(r.cardDue), r.cardLimit > 0 ? "Limit " + Money.inr(r.cardLimit) : ""});
        tiles.add(new String[]{"Loans outstanding", Money.inr(r.loanOutstanding), ""});
        tiles.add(new String[]{"EMIs per month", Money.inr(r.monthlyEmi), ""});
        if (r.deposits > 0) tiles.add(new String[]{"Deposits", Money.inr(r.deposits), ""});
        if (r.cardAvailable > 0) tiles.add(new String[]{"Card limit available", Money.inr(r.cardAvailable), ""});

        for (int i = 0; i < tiles.size(); i += 2) {
            LinearLayout row = Ui.hbox(this);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            row.setLayoutParams(rp);
            for (int k = i; k < Math.min(i + 2, tiles.size()); k++) {
                LinearLayout t = Ui.card(this);
                String[] d = tiles.get(k);
                t.addView(Ui.text(this, d[0], 12, Ui.MUTED, false));
                t.addView(Ui.text(this, d[1], 17, Ui.INK, true));
                if (!d[2].isEmpty()) t.addView(Ui.text(this, d[2], 11, Ui.MUTED, false));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                lp.bottomMargin = Ui.dp(this, 10);
                if (k == i) lp.rightMargin = Ui.dp(this, 5); else lp.leftMargin = Ui.dp(this, 5);
                row.addView(t, lp);
            }
            if (i + 1 >= tiles.size()) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 0, 1f);
                lp.leftMargin = Ui.dp(this, 5);
                row.addView(new LinearLayout(this), lp);
            }
            root.addView(row);
        }
    }

    private void addUpcoming(LinearLayout root, Aggregator.Result r) {
        long now = System.currentTimeMillis();
        long dayMs = 86400000L;
        List<Object[]> items = new ArrayList<>();
        for (Account a : r.accounts) {
            if (a.dueDate.v == null) continue;
            if (a.type == AccountType.CREDIT_CARD && a.duePaid()) continue;
            long d = Dates.parse(a.dueDate.v);
            if (d < 0 || d < now - dayMs || d > now + 45 * dayMs) continue;
            Double amt = a.type == AccountType.CREDIT_CARD ? a.totalDue.v : a.emi.v;
            items.add(new Object[]{d, a, amt});
        }
        if (items.isEmpty()) return;
        items.sort((x, y) -> Long.compare((Long) x[0], (Long) y[0]));
        root.addView(Ui.heading(this, "Upcoming dues"));
        LinearLayout c = Ui.card(this);
        for (Object[] it : items) {
            Account a = (Account) it[1];
            long d = (Long) it[0];
            long days = (d - now) / dayMs;
            String when = Ui.day(d) + (days <= 0 ? " · today" : days == 1 ? " · tomorrow" : " · in " + days + " days");
            String what = (a.type == AccountType.CREDIT_CARD ? "Card " : "EMI ") + a.label();
            c.addView(Ui.row(this, what + "\n" + when, it[2] == null ? "—" : Money.inr((Double) it[2]), days <= 3 ? Ui.RED : Ui.INK));
        }
        root.addView(c);
    }

    private LinearLayout accountCard(Account a) {
        LinearLayout c = Ui.card(this);
        c.setClickable(true);
        c.setOnClickListener(v -> {
            Intent i = new Intent(this, AccountActivity.class);
            i.putExtra("key", a.key());
            startActivity(i);
        });
        c.addView(Ui.text(this, a.label(), 15, Ui.INK, true));

        String main = null, mainLabel = "", asOf = "";
        int color = Ui.INK;
        switch (a.type) {
            case SAVINGS:
                if (a.balance.v != null) { main = Money.inr(a.balance.v); mainLabel = "Balance"; asOf = Ui.when(a.balance.t); color = a.balance.v < 0 ? Ui.RED : Ui.GREEN; }
                break;
            case CREDIT_CARD:
                if (a.totalDue.v != null) {
                    main = Money.inr(a.totalDue.v);
                    mainLabel = a.duePaid() ? "Last bill (paid)" : "Amount due";
                    asOf = Ui.day(a.totalDue.t);
                    color = a.duePaid() ? Ui.GREEN : Ui.RED;
                } else if (a.availableLimit.v != null) {
                    main = Money.inr(a.availableLimit.v); mainLabel = "Available limit"; asOf = Ui.when(a.availableLimit.t);
                }
                break;
            case LOAN:
                if (a.outstanding.v != null) { main = Money.inr(a.outstanding.v); mainLabel = "Outstanding"; asOf = Ui.day(a.outstanding.t); color = Ui.AMBER; }
                else if (a.emi.v != null) { main = Money.inr(a.emi.v); mainLabel = "EMI"; asOf = Ui.day(a.emi.t); }
                break;
            case DEPOSIT:
                Account.Val dv = a.depositAmount.v != null ? a.depositAmount : a.maturityAmount;
                if (dv.v != null) { main = Money.inr(dv.v); mainLabel = a.depositAmount.v != null ? "Deposit" : "Maturity value"; asOf = Ui.day(dv.t); color = Ui.GREEN; }
                break;
            default:
                break;
        }
        if (main != null) {
            LinearLayout r = Ui.hbox(this);
            TextView l = Ui.text(this, mainLabel + (asOf.isEmpty() ? "" : "\nas of " + asOf), 12, Ui.MUTED, false);
            TextView v = Ui.text(this, main, 20, color, true);
            r.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            r.addView(v);
            r.setPadding(0, Ui.dp(this, 6), 0, 0);
            c.addView(r);
        }

        List<String> extra = new ArrayList<>();
        if (a.type == AccountType.CREDIT_CARD) {
            if (a.minDue.v != null && !a.duePaid()) extra.add("Min due " + Money.inr(a.minDue.v));
            if (a.dueDate.v != null && !a.duePaid()) extra.add("Due " + a.dueDate.v);
            if (a.creditLimit.v != null) extra.add("Limit " + Money.inr(a.creditLimit.v));
            if (a.availableLimit.v != null && a.totalDue.v != null) extra.add("Available " + Money.inr(a.availableLimit.v));
        } else if (a.type == AccountType.LOAN) {
            if (a.emi.v != null && a.outstanding.v != null) extra.add("EMI " + Money.inr(a.emi.v));
            if (a.dueDate.v != null) extra.add("Next due " + a.dueDate.v);
            if (a.hasCurrentOverdue()) extra.add("Overdue " + Money.inr(a.overdue.v));
        } else if (a.type == AccountType.DEPOSIT) {
            if (a.maturityAmount.v != null && a.depositAmount.v != null) extra.add("Maturity " + Money.inr(a.maturityAmount.v));
            if (a.maturityDate.v != null) extra.add("Matures " + a.maturityDate.v);
        }
        if (main == null && !a.txns.isEmpty()) extra.add("Balance not mentioned in alerts yet");
        if (!a.txns.isEmpty()) extra.add(a.txns.size() + " recent transactions");
        if (!extra.isEmpty()) {
            TextView e = Ui.text(this, String.join("  ·  ", extra), 12, Ui.MUTED, false);
            e.setPadding(0, Ui.dp(this, 6), 0, 0);
            c.addView(e);
        }
        return c;
    }
}
