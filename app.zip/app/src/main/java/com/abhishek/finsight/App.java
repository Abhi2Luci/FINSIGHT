package com.abhishek.finsight;

import android.app.Application;
import android.content.Context;
import android.os.Build;

import java.io.PrintWriter;
import java.io.StringWriter;

/** Catches any crash, saves the details, and shows them the next time the app opens. */
public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                saveCrash(this, thread.getName(), error);
            } catch (Throwable ignored) {
            }
            if (previous != null) previous.uncaughtException(thread, error);
            else {
                android.os.Process.killProcess(android.os.Process.myPid());
                System.exit(10);
            }
        });
    }

    static void saveCrash(Context c, String where, Throwable error) {
        StringWriter sw = new StringWriter();
        error.printStackTrace(new PrintWriter(sw));
        String trace = sw.toString();
        if (trace.length() > 6000) trace = trace.substring(0, 6000);
        String info = "FinSight " + BuildConfigInfo.version(c) + " · Android " + Build.VERSION.RELEASE
                + " (API " + Build.VERSION.SDK_INT + ") · " + Build.MANUFACTURER + " " + Build.MODEL
                + " · thread " + where + "\n\n" + trace;
        Store.prefs(c).edit().putString("last_crash", info).putLong("last_crash_time", System.currentTimeMillis()).commit();
    }

    static String takeCrash(Context c) {
        String s = Store.prefs(c).getString("last_crash", "");
        return s == null ? "" : s;
    }

    static void clearCrash(Context c) {
        Store.prefs(c).edit().remove("last_crash").remove("last_crash_time").commit();
    }

    /** Version name without needing the generated BuildConfig class. */
    static final class BuildConfigInfo {
        static String version(Context c) {
            try {
                return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "?";
            }
        }
    }
}
