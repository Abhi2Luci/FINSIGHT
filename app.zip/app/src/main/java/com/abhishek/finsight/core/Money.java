package com.abhishek.finsight.core;

/** Amount parsing and Indian-style formatting (12,34,567.89). */
public final class Money {
    private Money() {}

    public static Double parse(String s) {
        if (s == null) return null;
        String t = s.replace(",", "").trim();
        if (t.isEmpty()) return null;
        if (t.endsWith(".")) t = t.substring(0, t.length() - 1);
        try {
            double v = Double.parseDouble(t);
            if (v < 0 || v > 1e11) return null;
            return v;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static String inr(Double v) {
        if (v == null) return "—";
        return inr(v.doubleValue());
    }

    public static String inr(double v) {
        boolean neg = v < 0;
        long paise = Math.round(Math.abs(v) * 100);
        long rupees = paise / 100;
        long p = paise % 100;
        String r = Long.toString(rupees);
        StringBuilder sb = new StringBuilder();
        if (r.length() <= 3) {
            sb.append(r);
        } else {
            String last3 = r.substring(r.length() - 3);
            String rest = r.substring(0, r.length() - 3);
            StringBuilder head = new StringBuilder();
            int i = rest.length();
            while (i > 2) {
                head.insert(0, "," + rest.substring(i - 2, i));
                i -= 2;
            }
            head.insert(0, rest.substring(0, i));
            sb.append(head).append(',').append(last3);
        }
        String out = "₹" + sb + (p == 0 ? "" : String.format(".%02d", p));
        return neg ? "-" + out : out;
    }
}
