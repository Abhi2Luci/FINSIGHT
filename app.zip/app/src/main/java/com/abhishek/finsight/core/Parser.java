package com.abhishek.finsight.core;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads one bank / card / loan message and pulls out account numbers (last digits),
 * balances, dues, limits, EMIs, outstanding amounts, deposits and transactions.
 * Works on lower-case text; all patterns are written in lower case.
 */
public final class Parser {
    private Parser() {}

    private static final String CUR = "(?:rs\\.?|inr|₹|rupees)";
    private static final String AMT = "([0-9][0-9,]*(?:\\.[0-9]{1,2})?)";
    private static final String CA = CUR + "\\s*:?\\s*" + AMT;
    private static final String DATE = "(\\d{1,2}[-/.](?:\\d{1,2}|[a-z]{3,9})[-/.]\\d{2,4}"
            + "|\\d{1,2}(?:st|nd|rd|th)?[ -](?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[ ,-]+\\d{2,4}"
            + "|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\s+\\d{1,2}(?:st|nd|rd|th)?,?\\s+\\d{4}"
            + "|\\d{4}-\\d{2}-\\d{2})";

    private static String gap(int n) {
        return "[^\\n]{0," + n + "}?";
    }

    private static Pattern p(String s) {
        return Pattern.compile(s);
    }

    // ---- account identifiers ----
    private static final Pattern ID_MASK = p("(?<![a-wyz0-9])(?:x|\\*|#|•){2,}\\s?-?(\\d{3,6})(?!\\d)");
    private static final Pattern ID_X1 = p("(?:a/c|acct?|account|card|(?<![a-z])ac)\\s*(?:no\\.?|number)?\\s*[:\\-]?\\s*x(\\d{3,6})(?!\\d)");
    private static final Pattern ID_END = p("(?:ending|ends)(?:\\s+(?:with|in))?\\s*[:\\-]?\\s*(?:no\\.?\\s*)?(?:x+|\\*+)?(\\d{3,6})(?!\\d)");
    private static final Pattern ID_FULL = p("(?:a/c|acct|account|(?<![a-z])ac)\\s*(?:no\\.?|number|num|#)?\\s*[:\\-.]?\\s*(\\d{6,18})(?!\\d)");
    private static final Pattern ID_CARD4 = p("(?:credit\\s*card|bank\\s*card|(?<![a-z])card|(?<![a-z])cc)\\s+(\\d{4})(?![\\d,.])");
    private static final Pattern ID_NO = p("(?:loan|card)\\s*(?:a/c\\s*)?(?:no\\.?|number|#)\\s*[:\\-.]?\\s*(\\d{6,18})(?!\\d)");

    // ---- amounts ----
    private static final Pattern ANY_AMT = p(CA);
    private static final Pattern BAL = p("(?:(?<![a-z])bal(?:ance)?|avlbal|avbl)\\b\\.?(" + gap(60) + ")" + CA + "(\\s*\\(?dr\\b)?");
    private static final Pattern BAL_LOOSE = p("(?:(?<![a-z])bal(?:ance)?|avlbal|avbl)\\b\\.?\\s*(?:is|:|-)?\\s*:?\\s*([0-9][0-9,]*\\.[0-9]{2})(\\s*\\(?dr\\b)?");
    private static final Pattern TOTAL_DUE = p("(?:total\\s*(?:amount|amt\\.?)?\\s*(?:due|payable)|amount\\s+due|amt\\.?\\s+due|(?<![a-z])tad\\b|statement\\s*(?:balance|amount|amt\\.?|bal\\.?|outstanding)|total\\s+outstanding|(?:closing|current)\\s+outstanding)" + gap(30) + CA);
    private static final Pattern MIN_DUE = p("(?:min(?:imum)?\\.?\\s*(?:amount|amt\\.?)?\\s*(?:due|payable)|(?<![a-z])mad\\b)" + gap(30) + CA);
    private static final Pattern AVL_LIMIT = p("(?:(?:avl|avail(?:able)?|avbl)\\.?\\s*(?:credit\\s*|cr\\.?\\s*)?(?:lmt|limit)|(?:avl|available)\\s+credit)\\b" + gap(20) + CA);
    private static final Pattern CREDIT_LIMIT = p("(?:credit|card|cr\\.?)\\s*(?:lmt|limit)\\b" + gap(20) + CA);
    private static final Pattern PAYMENT1 = p("(?:payment|pymt|repayment)\\s+(?:of\\s+)?" + CA + gap(80) + "(?:received|credited|successful|processed|realised|realized)");
    private static final Pattern PAYMENT2 = p("(?:received|thank you for)\\s+(?:your\\s+|the\\s+)?(?:payment|pymt)\\s+(?:of\\s+)?" + CA);
    private static final Pattern EMI = p("(?<![a-z])emi\\b(?:\\s+amount|\\s+amt\\.?)?" + gap(40) + CA);
    private static final Pattern EMI2 = p(CA + "\\s*(?:is\\s+)?(?:due\\s+)?(?:towards|for|as)\\s+(?:your\\s+|the\\s+)?(?:loan\\s+)?(?:emi|instal+ment)");
    private static final Pattern OUTSTANDING = p("(?:(?:principal\\s+)?(?:outstanding|o/s)\\s*(?:principal|balance|amount|amt\\.?|bal\\.?|loan)?|loan\\s+(?:balance|bal\\.?))" + gap(25) + CA);
    private static final Pattern OVERDUE = p("(?:overdue|over\\s+due|arrears?|unpaid\\s+emi)" + gap(25) + CA);
    private static final Pattern DUE_DATE = p("(?:due\\s*date|due\\s+on|due\\s+by|payable\\s+(?:on|by|before)|pay(?:ment)?\\s+(?:by|before)|is\\s+due|due)\\s*(?:is|of|:|-|on)?\\s*:?\\s*(?:on\\s+)?" + DATE);
    private static final Pattern DEPOSIT_AMT = p("(?:deposit(?:ed)?\\s*(?:amount|amt\\.?|of|value)|principal(?:\\s+amount)?|(?:fd|rd)\\s+(?:of|amount|amt\\.?|for)|(?:fixed|term|recurring)\\s+deposit\\s+(?:of|for))" + gap(20) + CA);
    private static final Pattern DEPOSIT_AMT2 = p("(?:(?<![a-z])fd|(?<![a-z])rd|tdr|deposit)\\b" + gap(30) + "\\b(?:for|of)\\s+" + CA);
    private static final Pattern MATURITY_AMT = p("maturity\\s*(?:amount|value|amt\\.?|proceeds)" + gap(20) + CA);
    private static final Pattern MATURITY_DATE = p("matur(?:ity\\s*date|ity\\s+on|es\\s+on|ing\\s+on|ity|es)\\s*(?:is|:|-|on)?\\s*:?\\s*" + DATE);

    // ---- words ----
    private static final Pattern DEBIT_WORDS = p("\\b(?:debited|debit\\s+of|debit\\s+for|withdrawn|withdrawal|spent|deducted|paid|sent|transferred\\s+to|purchase|txn\\s+of|used\\s+for)\\b");
    private static final Pattern CREDIT_WORDS = p("\\b(?:credited|received|deposited|refund(?:ed)?|reversed|cashback)\\b");
    private static final Pattern NOT_A_TXN = p("\\b(?:will\\s+be|is\\s+due|are\\s+due|due\\s+on|due\\s+date|scheduled|upcoming|requested|request|reminder|failed|declined|unsuccessful|not\\s+been|insufficient|would\\s+be|to\\s+be\\s+debited)\\b");
    private static final Pattern OTP = p("\\b(?:otp|one\\s+time\\s+password|verification\\s+code|passcode)\\b");
    private static final Pattern PROMO = p("pre-?\\s?approved|apply\\s+now|eligible\\s+for|get\\s+instant|instant\\s+loan|\\boffer\\b|congratulations|limited\\s+period|hurry|lowest\\s+(?:interest|rate)|get\\s+up\\s*to|avail\\s+now|apply\\s+for|loan\\s+of\\s+up\\s*to|\\bupgrade\\b|exclusive|\\bwin\\b|lucky|click\\s+here\\s+to\\s+apply");
    private static final Pattern BAL_EXCLUDE = p("charge|fee|penalt|maintain|minimum|\\bmin\\b|required|shortfall|average|\\bamb\\b|\\bqab\\b|keep");
    private static final Pattern EMI_PROMO = p("convert|conversion|no[\\s-]cost|easy\\s+emi|eligible|option");
    private static final Pattern TXN_VERBS = p("\\b(?:debited|credited|from|to|withdrawn|deposited|via|using|by)\\b");

    private static final Pattern CREDIT_CARD_HINT = p("credit\\s*card|(?:avl|available|avail)\\.?\\s*(?:credit\\s*)?(?:lmt|limit)|credit\\s+limit|total\\s*(?:amount|amt\\.?)?\\s*due|min(?:imum)?\\.?\\s*(?:amount|amt\\.?)?\\s*due|card\\s+statement|(?<![a-z])tad\\b");
    private static final Pattern LOAN_HINT = p("\\bloan\\b|(?<![a-z])emi\\b");
    private static final Pattern DEPOSIT_HINT = p("fixed\\s+deposit|term\\s+deposit|recurring\\s+deposit|(?<![a-z])(?:fd|rd|tdr|stdr)\\b|deposit\\s+(?:a/c|account)");

    private static final class IdHit {
        final int pos;
        final String last4;
        AccountType type;

        IdHit(int pos, String digits) {
            this.pos = pos;
            this.last4 = digits.length() > 4 ? digits.substring(digits.length() - 4) : digits;
        }
    }

    private static final class Found {
        final double value;
        final int start;
        final int end;
        final boolean negative;

        Found(double value, int start, int end, boolean negative) {
            this.value = value;
            this.start = start;
            this.end = end;
            this.negative = negative;
        }
    }

    public static String normalize(String s) {
        String t = s.replace(' ', ' ').replace(' ', ' ').replace(' ', ' ')
                .replace('‎', ' ').replace('‏', ' ').replace('\r', '\n');
        t = t.replaceAll("[ \\t]+", " ");
        return t;
    }

    /** Lower-cases one char at a time so positions stay the same. */
    private static String lower(String s) {
        char[] c = s.toCharArray();
        for (int i = 0; i < c.length; i++) c[i] = Character.toLowerCase(c[i]);
        return new String(c);
    }

    public static List<Update> parse(RawMessage m) {
        List<Update> out = new ArrayList<>();
        if (m == null || m.text == null || m.text.isEmpty()) return out;
        String text = normalize(m.text);
        if (text.length() > 9000) text = text.substring(0, 9000);
        String lo = lower(text);
        if (!quickCheck(lo)) return out;

        if (OTP.matcher(lo).find()) return out;
        String head = lo.substring(0, Math.min(220, lo.length()));
        if (PROMO.matcher(head).find()) return out;
        boolean anyAmt = ANY_AMT.matcher(lo).find() || BAL_LOOSE.matcher(lo).find();
        if (!anyAmt) return out;

        boolean creditMsg = CREDIT_CARD_HINT.matcher(lo).find();
        boolean loanMsg = LOAN_HINT.matcher(lo).find();
        boolean depositMsg = DEPOSIT_HINT.matcher(lo).find();
        boolean txnVerbs = DEBIT_WORDS.matcher(lo).find() || CREDIT_WORDS.matcher(lo).find();
        AccountType msgType = creditMsg ? AccountType.CREDIT_CARD
                : depositMsg ? AccountType.DEPOSIT
                : (loanMsg && !txnVerbs) ? AccountType.LOAN
                : AccountType.SAVINGS;

        List<IdHit> ids = findIds(lo);
        for (IdHit h : ids) h.type = classify(lo, h.pos, msgType, creditMsg);

        String bank = Banks.detect(m.sender, lo);
        Map<AccountType, Update> byType = new EnumMap<>(AccountType.class);
        for (IdHit h : ids) {
            if (!byType.containsKey(h.type)) byType.put(h.type, newUpdate(m, text, bank, h.type, h.last4));
        }

        List<int[]> used = new ArrayList<>();

        // Credit card figures
        Found minDue = find(MIN_DUE, lo, null, 0);
        Found totalDue = findNotPreceded(TOTAL_DUE, lo, "min");
        Found avlLimit = find(AVL_LIMIT, lo, null, 0);
        Found limit = findNotPreceded(CREDIT_LIMIT, lo, "avl|avail|available|avbl");
        Found payment = find(PAYMENT1, lo, null, 0);
        if (payment == null) payment = find(PAYMENT2, lo, null, 0);
        boolean cardFigures = minDue != null || totalDue != null || avlLimit != null || limit != null;

        Update card = byType.get(AccountType.CREDIT_CARD);
        if (card == null && cardFigures && creditMsg && ids.isEmpty()) {
            card = newUpdate(m, text, bank, AccountType.CREDIT_CARD, "");
            byType.put(AccountType.CREDIT_CARD, card);
        }
        if (card != null) {
            if (totalDue != null) { card.totalDue = totalDue.value; mark(used, totalDue); }
            if (minDue != null) { card.minDue = minDue.value; mark(used, minDue); }
            if (avlLimit != null) { card.availableLimit = avlLimit.value; mark(used, avlLimit); }
            if (limit != null) { card.creditLimit = limit.value; mark(used, limit); }
            if (payment != null && creditMsg) card.lastPayment = payment.value;
        }

        // Loan figures
        Found emi = find(EMI, lo, EMI_PROMO, 30);
        if (emi == null) emi = find(EMI2, lo, null, 0);
        Found outstanding = find(OUTSTANDING, lo, null, 0);
        Found overdue = find(OVERDUE, lo, null, 0);
        boolean loanFigures = emi != null || outstanding != null || overdue != null;
        Update loan = byType.get(AccountType.LOAN);
        if (loan == null && loanFigures && loanMsg && !creditMsg) {
            loan = newUpdate(m, text, bank, AccountType.LOAN, "");
            byType.put(AccountType.LOAN, loan);
        }
        if (loan != null) {
            if (emi != null) loan.emi = emi.value;
            if (outstanding != null) { loan.outstanding = outstanding.value; mark(used, outstanding); }
            if (overdue != null) { loan.overdue = overdue.value; mark(used, overdue); }
        } else if (card != null && outstanding != null && card.totalDue == null) {
            card.totalDue = outstanding.value;
            mark(used, outstanding);
        }

        // Deposit figures
        Found depAmt = find(DEPOSIT_AMT, lo, null, 0);
        if (depAmt == null && depositMsg) depAmt = find(DEPOSIT_AMT2, lo, null, 0);
        Found matAmt = find(MATURITY_AMT, lo, null, 0);
        String matDate = group(MATURITY_DATE, lo, 1);
        Update dep = byType.get(AccountType.DEPOSIT);
        if (dep == null && depositMsg && (depAmt != null || matAmt != null) && ids.isEmpty()) {
            dep = newUpdate(m, text, bank, AccountType.DEPOSIT, "");
            byType.put(AccountType.DEPOSIT, dep);
        }
        if (dep != null) {
            if (depAmt != null) { dep.depositAmount = depAmt.value; mark(used, depAmt); }
            if (matAmt != null) { dep.maturityAmount = matAmt.value; mark(used, matAmt); }
            if (matDate != null) dep.maturityDate = matDate;
        }

        // Due date
        String due = group(DUE_DATE, lo, 1);
        if (due != null) {
            if (card != null && (card.totalDue != null || card.minDue != null)) card.dueDate = due;
            else if (loan != null) loan.dueDate = due;
            else if (card != null) card.dueDate = due;
        }

        // Balance
        Found bal = findBalance(lo);
        Update savings = byType.get(AccountType.SAVINGS);
        if (savings == null && byType.containsKey(AccountType.DEBIT_CARD)) {
            Update dc = byType.remove(AccountType.DEBIT_CARD);
            dc.type = AccountType.SAVINGS;
            dc.viaDebitCard = true;
            savings = dc;
            byType.put(AccountType.SAVINGS, dc);
        }
        if (bal != null && !overlaps(used, bal)) {
            double v = bal.negative ? -bal.value : bal.value;
            if (savings != null) savings.balance = v;
            else if (card != null) { if (card.availableLimit == null) card.availableLimit = bal.value; }
            else if (loan != null) { if (loan.outstanding == null) loan.outstanding = bal.value; }
            else if (dep != null) { if (dep.depositAmount == null) dep.depositAmount = bal.value; }
            mark(used, bal);
        }

        // Transaction
        Update txnTarget = savings != null ? savings : card;
        if (txnTarget != null && !NOT_A_TXN.matcher(lo).find()) {
            Txn t = findTxn(lo, text, used, m);
            if (t != null) txnTarget.txn = t;
        }

        for (Update u : byType.values()) {
            if (u.type != AccountType.DEBIT_CARD && u.hasData()) out.add(u);
        }
        return out;
    }

    private static final String[] QUICK = {"a/c", "acct", "account", "card", "loan", "bal", "emi", "deposit", "xx", "**", "ac "};

    /** Cheap test so most everyday messages skip the regular expressions. */
    private static boolean quickCheck(String lo) {
        boolean digit = false;
        for (int i = 0; i < lo.length(); i++) {
            if (Character.isDigit(lo.charAt(i))) { digit = true; break; }
        }
        if (!digit) return false;
        for (String q : QUICK) if (lo.contains(q)) return true;
        return false;
    }

    private static Update newUpdate(RawMessage m, String text, String bank, AccountType type, String last4) {
        Update u = new Update();
        u.type = type;
        u.bank = bank;
        u.last4 = last4;
        u.time = m.time;
        u.source = m.source;
        u.sender = m.sender;
        u.text = text.length() > 500 ? text.substring(0, 500) + "…" : text;
        return u;
    }

    private static List<IdHit> findIds(String lo) {
        List<IdHit> hits = new ArrayList<>();
        Pattern[] ps = {ID_MASK, ID_X1, ID_END, ID_FULL, ID_NO, ID_CARD4};
        for (Pattern p : ps) {
            Matcher mt = p.matcher(lo);
            while (mt.find()) {
                IdHit h = new IdHit(mt.start(1), mt.group(1));
                boolean dup = false;
                for (IdHit o : hits) {
                    if (o.last4.equals(h.last4)) { dup = true; break; }
                }
                if (!dup) hits.add(h);
            }
        }
        hits.sort((a, b) -> Integer.compare(a.pos, b.pos));
        return hits;
    }

    private static final Pattern K_CREDIT_CARD = p("credit\\s*card");
    private static final Pattern K_DEBIT_CARD = p("debit\\s*card|atm\\s*card|rupay\\s*card");
    private static final Pattern K_CARD = p("\\bcard\\b");
    private static final Pattern K_LOAN = p("\\bloan\\b|(?<![a-z])emi\\b");
    private static final Pattern K_DEP = p("deposit|(?<![a-z])(?:fd|rd|tdr|stdr)\\b");

    /** Decide what kind of account the identifier at {@code pos} belongs to, from the words just before it. */
    private static AccountType classify(String lo, int pos, AccountType msgType, boolean creditMsg) {
        int from = Math.max(0, pos - 32);
        String w = lo.substring(from, pos);
        int best = -1;
        AccountType type = null;
        int i;
        if ((i = lastIndex(K_CREDIT_CARD, w)) > best) { best = i; type = AccountType.CREDIT_CARD; }
        if ((i = lastIndex(K_DEBIT_CARD, w)) > best) { best = i; type = AccountType.DEBIT_CARD; }
        if ((i = lastIndex(K_CARD, w)) > best) {
            boolean partOfOther = type != null && i <= best + 12;
            if (!partOfOther) { best = i; type = creditMsg ? AccountType.CREDIT_CARD : AccountType.DEBIT_CARD; }
        }
        if ((i = lastIndex(K_LOAN, w)) > best) { best = i; type = AccountType.LOAN; }
        if ((i = lastIndex(K_DEP, w)) > best) { best = i; type = AccountType.DEPOSIT; }

        if (type != null) {
            if (type == AccountType.LOAN || type == AccountType.DEPOSIT) {
                // "EMI of Rs 5000 debited from a/c XX1234" -> the a/c is a savings account
                String between = w.substring(best);
                if (TXN_VERBS.matcher(between).find()) return AccountType.SAVINGS;
            }
            return type;
        }
        return msgType;
    }

    private static int lastIndex(Pattern p, String s) {
        Matcher m = p.matcher(s);
        int idx = -1;
        while (m.find()) idx = m.start();
        return idx;
    }

    private static Found find(Pattern p, String lo, Pattern excludeInMatch, int amtGroupOffsetUnused) {
        Matcher m = p.matcher(lo);
        while (m.find()) {
            if (excludeInMatch != null && excludeInMatch.matcher(lo.substring(Math.max(0, m.start() - 20), m.end())).find()) continue;
            String g = lastAmountGroup(m);
            Double v = Money.parse(g);
            if (v != null && v > 0) return new Found(v, m.start(), m.end(), false);
        }
        return null;
    }

    /** The amount is always the last capturing group that holds digits. */
    private static String lastAmountGroup(Matcher m) {
        for (int g = m.groupCount(); g >= 1; g--) {
            String s = m.group(g);
            if (s != null && !s.isEmpty() && Character.isDigit(s.charAt(0))) return s;
        }
        return null;
    }

    private static Found findNotPreceded(Pattern p, String lo, String notBefore) {
        Pattern nb = Pattern.compile("(?:" + notBefore + ")[\\s.]*$");
        Matcher m = p.matcher(lo);
        while (m.find()) {
            String before = lo.substring(Math.max(0, m.start() - 14), m.start());
            if (nb.matcher(before).find()) continue;
            Double v = Money.parse(lastAmountGroup(m));
            if (v != null && v > 0) return new Found(v, m.start(), m.end(), false);
        }
        return null;
    }

    private static Found findBalance(String lo) {
        Matcher m = BAL.matcher(lo);
        while (m.find()) {
            String gapText = m.group(1);
            String before = lo.substring(Math.max(0, m.start() - 25), m.start());
            if (BAL_EXCLUDE.matcher(gapText).find() || BAL_EXCLUDE.matcher(before).find()) continue;
            Double v = Money.parse(m.group(2));
            if (v != null) return new Found(v, m.start(), m.end(), m.group(3) != null);
        }
        m = BAL_LOOSE.matcher(lo);
        while (m.find()) {
            String before = lo.substring(Math.max(0, m.start() - 25), m.start());
            if (BAL_EXCLUDE.matcher(before).find()) continue;
            Double v = Money.parse(m.group(1));
            if (v != null) return new Found(v, m.start(), m.end(), m.group(2) != null);
        }
        return null;
    }

    private static String group(Pattern p, String lo, int g) {
        Matcher m = p.matcher(lo);
        return m.find() ? m.group(g) : null;
    }

    private static void mark(List<int[]> used, Found f) {
        used.add(new int[]{f.start, f.end});
    }

    private static boolean overlaps(List<int[]> used, Found f) {
        for (int[] r : used) if (f.start < r[1] && r[0] < f.end) return true;
        return false;
    }

    private static boolean inUsed(List<int[]> used, int pos) {
        for (int[] r : used) if (pos >= r[0] && pos < r[1]) return true;
        return false;
    }

    private static Txn findTxn(String lo, String text, List<int[]> used, RawMessage m) {
        Matcher d = DEBIT_WORDS.matcher(lo);
        Matcher c = CREDIT_WORDS.matcher(lo);
        int di = d.find() ? d.start() : -1;
        int ci = c.find() ? c.start() : -1;
        if (di < 0 && ci < 0) return null;
        boolean credit;
        int kw;
        if (di >= 0 && (ci < 0 || di <= ci)) { credit = false; kw = di; } else { credit = true; kw = ci; }

        Matcher a = ANY_AMT.matcher(lo);
        Double best = null;
        int bestDist = Integer.MAX_VALUE;
        while (a.find()) {
            if (inUsed(used, a.start())) continue;
            Double v = Money.parse(a.group(1));
            if (v == null || v <= 0) continue;
            int dist = Math.abs(a.start() - kw);
            if (dist < bestDist && dist < 90) { bestDist = dist; best = v; }
        }
        if (best == null) return null;
        String desc = text.replace('\n', ' ');
        if (desc.length() > 140) desc = desc.substring(0, 140) + "…";
        return new Txn(m.time, best, credit, desc, m.source);
    }
}
