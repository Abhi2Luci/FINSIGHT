package com.abhishek.finsight;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Map;

/** Connect and manage sources: SMS, Gmail, notifications, chat imports, app lock, stored data. */
public class SourcesActivity extends LockedActivity {
    private static final int REQ_SMS = 11;
    private static final int REQ_FILE = 12;
    private static final int REQ_NOTIFY = 13;
    private boolean checking = false;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private String gmailStatus = "";
    private EditText idField, secretField;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTitle("Sources");
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // keep what was typed if the user switches to the browser to copy the key
        if (idField != null && secretField != null && !Gmail.signedIn(this)) {
            Gmail.saveClient(this, idField.getText().toString(), secretField.getText().toString());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!Lock.needsUnlock(this)) render(); // statuses may have changed in system settings
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void render() {
        idField = null;
        secretField = null;
        LinearLayout root = Ui.vbox(this);
        root.addView(Ui.text(this, "FinSight reads only on this phone. Nothing is uploaded anywhere; Gmail is read directly from Google with read-only access.", 13, Ui.MUTED, false));

        // SMS
        root.addView(Ui.heading(this, "1. SMS bank alerts"));
        LinearLayout sms = Ui.card(this);
        boolean smsOk = SmsReader.allowed(this);
        sms.addView(status(smsOk, smsOk ? "SMS access allowed" : "SMS access not allowed"));
        sms.addView(Ui.text(this, "Most Indian banks send balance, debit/credit, card and EMI alerts by SMS. This is the best source.", 13, Ui.MUTED, false));
        if (!smsOk) {
            sms.addView(Ui.button(this, "Allow SMS access", v -> requestPermissions(new String[]{Manifest.permission.READ_SMS}, REQ_SMS)));
            sms.addView(Ui.text(this, "If the option is greyed out or blocked: Settings → Apps → FinSight → ⋮ (top right) → Allow restricted settings, then try again.", 12, Ui.MUTED, false));
        }
        root.addView(sms);

        // Gmail
        root.addView(Ui.heading(this, "2. Gmail"));
        root.addView(gmailCard());

        // Notifications
        root.addView(Ui.heading(this, "3. WhatsApp, Telegram & bank-app notifications"));
        LinearLayout n = Ui.card(this);
        boolean nOk = NotifService.enabled(this);
        n.addView(status(nOk, nOk ? "Capturing new messages" : "Notification access is off"));
        n.addView(Ui.text(this, "WhatsApp and Telegram do not let other apps read old chats. With notification access, FinSight saves new bank messages as they arrive (only financial ones).", 13, Ui.MUTED, false));
        n.addView(Ui.button(this, nOk ? "Open notification access settings" : "Turn on notification access",
                v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))));
        if (!nOk) n.addView(Ui.text(this, "Greyed out? Settings → Apps → FinSight → ⋮ → Allow restricted settings, then come back.", 12, Ui.MUTED, false));
        root.addView(n);

        // Imports
        root.addView(Ui.heading(this, "4. Old WhatsApp / Telegram chats"));
        LinearLayout im = Ui.card(this);
        im.addView(Ui.text(this, "WhatsApp: open the bank's chat → ⋮ → More → Export chat → Without media → choose FinSight.\n"
                + "Telegram: on a computer use Telegram Desktop → ⋮ → Export chat history → format JSON, then open result.json here. On the phone you can copy messages and paste them.", 13, Ui.MUTED, false));
        im.addView(Ui.button(this, "Import a file (.txt, .zip, .json)", v -> pickFile()));
        im.addView(Ui.secondaryButton(this, "Paste messages", v -> pasteDialog()));
        root.addView(im);

        // Background checks
        root.addView(Ui.heading(this, "Background checks"));
        LinearLayout bg = Ui.card(this);
        Switch bgSw = new Switch(this);
        bgSw.setText("Check everything every 4 hours, even when the app is closed");
        bgSw.setTextColor(Ui.INK);
        bgSw.setChecked(Background.enabled(this));
        bgSw.setOnCheckedChangeListener((b, on) -> Background.setEnabled(this, on));
        bg.addView(bgSw);
        Switch remSw = new Switch(this);
        remSw.setText("Remind me 3 days before and on the day a card bill or EMI is due");
        remSw.setTextColor(Ui.INK);
        remSw.setChecked(Background.remindersOn(this));
        remSw.setOnCheckedChangeListener((b, on) -> {
            Background.setReminders(this, on);
            if (on && !Background.canNotify(this) && android.os.Build.VERSION.SDK_INT >= 33)
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY);
        });
        remSw.setPadding(0, Ui.dp(this, 10), 0, 0);
        bg.addView(remSw);
        long lr = Background.lastRun(this);
        bg.addView(Ui.text(this, (checking ? "Checking now…" : lr > 0 ? "Last background check: " + Ui.when(lr) : "No background check yet")
                + "\nEach check reads new SMS, fetches new Gmail bank e-mails and updates the dashboard. Android may delay checks when the battery is low.", 12, Ui.MUTED, false));
        if (!Background.canNotify(this) && android.os.Build.VERSION.SDK_INT >= 33) {
            bg.addView(Ui.button(this, "Allow notifications for reminders",
                    v -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY)));
        }
        bg.addView(Ui.secondaryButton(this, "Check now", v -> {
            if (checking) return;
            checking = true;
            render();
            new Thread(() -> {
                Background.runCheck(this);
                ui.post(() -> { checking = false; Ui.toast(this, "Check finished"); render(); });
            }).start();
        }));
        root.addView(bg);

        // Lock
        root.addView(Ui.heading(this, "Security"));
        LinearLayout sec = Ui.card(this);
        Switch sw = new Switch(this);
        sw.setText("Ask for fingerprint / screen lock to open");
        sw.setTextColor(Ui.INK);
        sw.setChecked(Lock.enabled(this));
        sw.setEnabled(Lock.deviceSecure(this));
        sw.setOnCheckedChangeListener((b, on) -> Lock.setEnabled(this, on));
        sec.addView(sw);
        if (!Lock.deviceSecure(this)) sec.addView(Ui.text(this, "Set a screen lock on your phone to use this.", 12, Ui.MUTED, false));
        root.addView(sec);

        // Data
        root.addView(Ui.heading(this, "Saved data"));
        LinearLayout d = Ui.card(this);
        Map<String, Integer> counts = Store.get(this).countsBySource();
        if (counts.isEmpty()) d.addView(Ui.text(this, "No saved messages yet (SMS are read live from your inbox and not copied).", 13, Ui.MUTED, false));
        for (Map.Entry<String, Integer> e : counts.entrySet()) d.addView(Ui.row(this, e.getKey(), e.getValue() + " messages", Ui.INK));
        d.addView(Ui.secondaryButton(this, "Delete all saved messages", v -> new AlertDialog.Builder(this)
                .setTitle("Delete saved messages?")
                .setMessage("Removes everything saved from Gmail, notifications and imports. Your SMS inbox is not touched.")
                .setPositiveButton("Delete", (x, y) -> {
                    Store.get(this).deleteAll();
                    Store.prefs(this).edit().remove("g_last_sync_ms").apply();
                    render();
                })
                .setNegativeButton("Cancel", null).show()));
        root.addView(d);

        setContentView(Ui.page(this, root));
    }

    private LinearLayout gmailCard() {
        LinearLayout g = Ui.card(this);
        boolean in = Gmail.signedIn(this);
        String email = Gmail.email(this);
        g.addView(status(in, in ? "Connected" + (email.isEmpty() ? "" : " as " + email) : "Not connected"));
        if (in) {
            long ls = Gmail.lastSync(this);
            g.addView(Ui.text(this, ls > 0 ? "Last checked " + Ui.when(ls) : "Not checked yet", 13, Ui.MUTED, false));
            if (!gmailStatus.isEmpty()) g.addView(Ui.text(this, gmailStatus, 13, Ui.INK, false));
            g.addView(Ui.button(this, "Check Gmail now", v -> syncGmail()));
            g.addView(Ui.secondaryButton(this, "Disconnect Gmail", v -> {
                Gmail.signOut(this);
                Store.get(this).deleteSource("Gmail");
                gmailStatus = "";
                render();
            }));
            return g;
        }

        g.addView(Ui.text(this, "Uses your own free Google Cloud key so only you have access. One-time setup, about 10 minutes.", 13, Ui.MUTED, false));
        g.addView(Ui.secondaryButton(this, "Show setup steps", v -> showGmailHelp()));
        EditText id = Ui.input(this, "Client ID (ends with .apps.googleusercontent.com)", Gmail.clientId(this), false);
        EditText secret = Ui.input(this, "Client secret", Gmail.clientSecret(this), false);
        g.addView(id);
        g.addView(secret);
        idField = id;
        secretField = secret;
        if (!gmailStatus.isEmpty()) {
            TextView st = Ui.text(this, gmailStatus, 13, Ui.RED, false);
            st.setTextIsSelectable(true);
            g.addView(st);
        }
        g.addView(Ui.button(this, "Sign in with Google", v -> {
            Gmail.saveClient(this, id.getText().toString(), secret.getText().toString());
            gmailStatus = "";
            Gmail.startSignIn(this, err -> {
                gmailStatus = err == null ? "" : err;
                if (err == null) syncGmail(); else render();
            });
        }));
        g.addView(Ui.text(this, "After you allow access, tap \"Return to FinSight\". If the browser shows an error page instead, copy the full address from the browser's address bar (it starts with http://127.0.0.1) and paste it here:", 12, Ui.MUTED, false));
        EditText pasted = Ui.input(this, "http://127.0.0.1:…/?state=…&code=…", "", false);
        g.addView(pasted);
        g.addView(Ui.secondaryButton(this, "Finish sign-in with pasted address", v -> {
            String url = pasted.getText().toString();
            new Thread(() -> {
                String err = Gmail.finishWithPastedUrl(this, url);
                ui.post(() -> {
                    gmailStatus = err == null ? "" : err;
                    if (err == null) syncGmail(); else render();
                });
            }).start();
        }));
        return g;
    }

    private void syncGmail() {
        gmailStatus = "Checking Gmail…";
        render();
        new Thread(() -> {
            String s;
            try {
                s = Gmail.sync(this, p -> ui.post(() -> { gmailStatus = p; render(); }));
            } catch (Exception e) {
                s = e.getMessage();
            }
            final String fs = s;
            ui.post(() -> {
                gmailStatus = fs == null ? "" : fs;
                render();
            });
        }).start();
    }

    private void showGmailHelp() {
        String steps = "On a computer (easier) or your phone's browser, open console.cloud.google.com and sign in with the same Gmail.\n\n"
                + "1. Create a project: top bar → Select a project → New project → name it FinSight → Create.\n\n"
                + "2. Enable Gmail: ☰ → APIs & Services → Library → search \"Gmail API\" → Enable.\n\n"
                + "3. Consent screen: ☰ → APIs & Services → OAuth consent screen (Google Auth Platform) → Get started. App name FinSight, your e-mail, Audience: External, finish.\n\n"
                + "4. Add yourself as tester: Audience → Test users → Add users → your Gmail address → Save.\n\n"
                + "5. Create the key: Clients → Create client → Application type: Desktop app → name FinSight → Create. Copy the Client ID and Client secret.\n\n"
                + "6. Paste both here and tap Sign in with Google. Google will warn \"Google hasn't verified this app\" — that is your own app, tap Continue, tick the Gmail permission and Continue.\n\n"
                + "Note: while the Google project is in Testing mode, Google asks you to sign in again about once a week.";
        TextView t = Ui.text(this, steps, 14, Ui.INK, false);
        t.setTextIsSelectable(true);
        int p = Ui.dp(this, 20);
        t.setPadding(p, p / 2, p, 0);
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.addView(t);
        new AlertDialog.Builder(this).setTitle("Gmail setup").setView(sv)
                .setPositiveButton("Open Google Cloud", (d, w) -> {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://console.cloud.google.com/apis/library/gmail.googleapis.com"));
                    startActivity(i);
                })
                .setNegativeButton("Close", null).show();
    }

    private TextView status(boolean ok, String s) {
        TextView t = Ui.text(this, (ok ? "● " : "○ ") + s, 15, ok ? Ui.GREEN : Ui.AMBER, true);
        t.setPadding(0, 0, 0, Ui.dp(this, 4));
        return t;
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/*", "application/zip", "application/x-zip-compressed", "application/json", "application/octet-stream"});
        startActivityForResult(i, REQ_FILE);
    }

    private void pasteDialog() {
        EditText e = Ui.input(this, "Paste bank messages here. Leave a blank line between messages.", "", true);
        int p = Ui.dp(this, 16);
        LinearLayout box = Ui.vbox(this);
        box.setPadding(p, p / 2, p, 0);
        box.addView(e);
        new AlertDialog.Builder(this).setTitle("Paste messages").setView(box)
                .setPositiveButton("Import", (d, w) -> {
                    String text = e.getText().toString();
                    new Thread(() -> {
                        Importer.Result r = Importer.importText(this, text, "Pasted");
                        ui.post(() -> { Ui.toast(this, r.describe()); render(); });
                    }).start();
                })
                .setNegativeButton("Cancel", null).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                Ui.toast(this, "Importing…");
                new Thread(() -> {
                    String msg;
                    try {
                        msg = Importer.importUri(this, uri).describe();
                    } catch (Exception ex) {
                        msg = "Import failed: " + ex.getMessage();
                    }
                    final String m = msg;
                    ui.post(() -> { Ui.toast(this, m); render(); });
                }).start();
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_NOTIFY) {
            render();
            return;
        }
        if (requestCode == REQ_SMS) {
            boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
            if (ok) {
                Store.get(this).markDirty();
            } else if (!shouldShowRequestPermissionRationale(Manifest.permission.READ_SMS)) {
                new AlertDialog.Builder(this).setTitle("SMS access")
                        .setMessage("Android blocked the request. Open App info → Permissions → SMS → Allow. If it says \"restricted setting\", first tap ⋮ → Allow restricted settings on the App info page.")
                        .setPositiveButton("Open App info", (d, w) -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + getPackageName()))))
                        .setNegativeButton("Cancel", null).show();
            }
            render();
        }
    }
}
