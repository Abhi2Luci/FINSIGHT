package com.abhishek.finsight.core;

import java.util.Locale;
import java.util.regex.Pattern;

/** Works out which bank or card issuer a message came from. */
public final class Banks {
    private Banks() {}

    public static final String UNKNOWN = "Unknown bank";

    /** SMS header codes (the part after "VM-", "AD-" etc). Checked with "contains". */
    private static final String[][] SMS_CODES = {
            {"SBICRD", "SBI Card"}, {"SBICARD", "SBI Card"}, {"SBIPAY", "SBI Card"},
            {"BOIIND", "Bank of India"}, {"BOIMSG", "Bank of India"}, {"BOISMS", "Bank of India"}, {"BOIBNK", "Bank of India"},
            {"SBIINB", "SBI"}, {"SBIUPI", "SBI"}, {"SBIPSG", "SBI"}, {"SBMSMS", "SBI"}, {"CBSSBI", "SBI"},
            {"ATMSBI", "SBI"}, {"SBYONO", "SBI"}, {"SBINEB", "SBI"}, {"SBIBNK", "SBI"},
            {"HDFCBK", "HDFC Bank"}, {"HDFCBN", "HDFC Bank"}, {"HDFCCC", "HDFC Bank"}, {"HDFCLN", "HDFC Bank"},
            {"ICICIB", "ICICI Bank"}, {"ICICIT", "ICICI Bank"}, {"ICICIO", "ICICI Bank"}, {"ICICIL", "ICICI Bank"},
            {"AXISBK", "Axis Bank"}, {"AXISMR", "Axis Bank"}, {"AXISCC", "Axis Bank"}, {"AXISIN", "Axis Bank"},
            {"KOTAKB", "Kotak Bank"}, {"KOTAKM", "Kotak Bank"}, {"KMBANK", "Kotak Bank"},
            {"PNBSMS", "PNB"}, {"PNBBNK", "PNB"}, {"PUNBNK", "PNB"},
            {"BOBTXN", "Bank of Baroda"}, {"BOBSMS", "Bank of Baroda"}, {"BARODA", "Bank of Baroda"}, {"BOBCRD", "BoB Card"},
            {"CANBNK", "Canara Bank"}, {"CANARA", "Canara Bank"},
            {"UNIONB", "Union Bank"}, {"UBOIND", "Union Bank"},
            {"INDBNK", "Indian Bank"}, {"IOBCHN", "Indian Overseas Bank"}, {"IOBBNK", "Indian Overseas Bank"},
            {"CENTBK", "Central Bank"}, {"CBOIND", "Central Bank"}, {"UCOBNK", "UCO Bank"},
            {"MAHABK", "Bank of Maharashtra"}, {"BOMBNK", "Bank of Maharashtra"}, {"PSBANK", "Punjab & Sind Bank"},
            {"IDFCFB", "IDFC FIRST Bank"}, {"IDFCBK", "IDFC FIRST Bank"},
            {"INDUSB", "IndusInd Bank"}, {"INDUSL", "IndusInd Bank"},
            {"YESBNK", "Yes Bank"}, {"YESBK", "Yes Bank"}, {"FEDBNK", "Federal Bank"},
            {"RBLBNK", "RBL Bank"}, {"RBLCRD", "RBL Bank"}, {"AUBANK", "AU Small Finance Bank"}, {"AUSFB", "AU Small Finance Bank"},
            {"BAJAJF", "Bajaj Finance"}, {"BAJFIN", "Bajaj Finance"}, {"HDBFSL", "HDB Financial"},
            {"TATACP", "Tata Capital"}, {"AMEXIN", "American Express"}, {"SCBANK", "Standard Chartered"},
            {"STANCB", "Standard Chartered"}, {"HSBCIN", "HSBC"}, {"DBSBNK", "DBS Bank"}, {"PAYTMB", "Paytm Payments Bank"},
            {"AIRBNK", "Airtel Payments Bank"}, {"IPPBNK", "India Post Payments Bank"}, {"LICHFL", "LIC Housing Finance"},
            {"ONECRD", "OneCard"}, {"SIBSMS", "South Indian Bank"}, {"KVBANK", "Karur Vysya Bank"}, {"JKBANK", "J&K Bank"},
    };

    /** E-mail domains. Checked with "contains" on the lower-case From header. */
    private static final String[][] DOMAINS = {
            {"sbicard", "SBI Card"}, {"hdfcbank", "HDFC Bank"}, {"sbi.co.in", "SBI"}, {"onlinesbi", "SBI"},
            {"bankofindia", "Bank of India"}, {"icicibank", "ICICI Bank"}, {"axisbank", "Axis Bank"}, {"kotak", "Kotak Bank"},
            {"pnb.co.in", "PNB"}, {"pnb.bank.in", "PNB"}, {"bankofbaroda", "Bank of Baroda"}, {"canarabank", "Canara Bank"},
            {"unionbankofindia", "Union Bank"}, {"indianbank", "Indian Bank"}, {"iob.in", "Indian Overseas Bank"},
            {"centralbank", "Central Bank"}, {"ucobank", "UCO Bank"}, {"bankofmaharashtra", "Bank of Maharashtra"},
            {"idfcfirstbank", "IDFC FIRST Bank"}, {"indusind", "IndusInd Bank"}, {"yesbank", "Yes Bank"},
            {"federalbank", "Federal Bank"}, {"rblbank", "RBL Bank"}, {"aubank", "AU Small Finance Bank"},
            {"bajajfinserv", "Bajaj Finance"}, {"americanexpress", "American Express"}, {"aexp.com", "American Express"},
            {"@sc.com", "Standard Chartered"}, {".sc.com", "Standard Chartered"}, {"hsbc", "HSBC"}, {"dbs.com", "DBS Bank"},
            {"hdbfs", "HDB Financial"}, {"tatacapital", "Tata Capital"}, {"lichousing", "LIC Housing Finance"},
            {"getonecard", "OneCard"}, {"southindianbank", "South Indian Bank"}, {"kvb.co.in", "Karur Vysya Bank"},
    };

    /** Names inside the text or sender name. Longer names first so "state bank of india" wins over "bank of india". */
    private static final Object[][] NAMES = {
            {"sbi\\s*card", "SBI Card"},
            {"state bank of india", "SBI"},
            {"central bank of india", "Central Bank"},
            {"union bank of india", "Union Bank"},
            {"indian overseas bank", "Indian Overseas Bank"},
            {"punjab\\s*(?:&|and)\\s*sind", "Punjab & Sind Bank"},
            {"bank of maharashtra", "Bank of Maharashtra"},
            {"bank of baroda", "Bank of Baroda"},
            {"bank of india", "Bank of India"},
            {"punjab national", "PNB"},
            {"\\bsbi\\b", "SBI"},
            {"\\bhdfc\\b", "HDFC Bank"},
            {"\\bicici\\b", "ICICI Bank"},
            {"\\baxis\\b", "Axis Bank"},
            {"\\bkotak\\b", "Kotak Bank"},
            {"\\bpnb\\b", "PNB"},
            {"canara", "Canara Bank"},
            {"union bank", "Union Bank"},
            {"indian bank", "Indian Bank"},
            {"\\buco bank", "UCO Bank"},
            {"\\bidfc", "IDFC FIRST Bank"},
            {"indusind", "IndusInd Bank"},
            {"\\byes bank", "Yes Bank"},
            {"federal bank", "Federal Bank"},
            {"\\brbl\\b", "RBL Bank"},
            {"au small finance", "AU Small Finance Bank"},
            {"bajaj fin", "Bajaj Finance"},
            {"american express|\\bamex\\b", "American Express"},
            {"standard chartered", "Standard Chartered"},
            {"\\bhsbc\\b", "HSBC"},
            {"\\bdbs\\b", "DBS Bank"},
            {"tata capital", "Tata Capital"},
            {"lic housing", "LIC Housing Finance"},
            {"onecard", "OneCard"},
            {"south indian bank", "South Indian Bank"},
            {"karur vysya", "Karur Vysya Bank"},
            {"paytm payments bank", "Paytm Payments Bank"},
            {"airtel payments bank", "Airtel Payments Bank"},
    };

    private static final Pattern[] NAME_PATTERNS = new Pattern[NAMES.length];

    static {
        for (int i = 0; i < NAMES.length; i++) {
            NAME_PATTERNS[i] = Pattern.compile((String) NAMES[i][0]);
        }
    }

    /** @param sender SMS header / e-mail From / chat sender; @param lowerText message text in lower case */
    public static String detect(String sender, String lowerText) {
        String s = sender == null ? "" : sender;
        String up = s.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9@.]", "");
        for (String[] c : SMS_CODES) {
            if (up.contains(c[0])) return c[1];
        }
        String low = s.toLowerCase(Locale.ROOT);
        for (String[] d : DOMAINS) {
            if (low.contains(d[0])) return d[1];
        }
        String byName = byName(low);
        if (byName != null) return byName;
        byName = byName(lowerText == null ? "" : lowerText);
        return byName != null ? byName : UNKNOWN;
    }

    private static String byName(String low) {
        for (int i = 0; i < NAME_PATTERNS.length; i++) {
            if (NAME_PATTERNS[i].matcher(low).find()) return (String) NAMES[i][1];
        }
        return null;
    }
}
