package com.abhishek.finsight;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.CancellationSignal;

/** Fingerprint / face / screen-lock gate for the app. */
final class Lock {
    private Lock() {}

    static final int REQUEST_CREDENTIAL = 701;
    private static long unlockedUntil = 0;

    static boolean enabled(Context c) {
        return Store.prefs(c).getBoolean("lock", true) && deviceSecure(c);
    }

    static void setEnabled(Context c, boolean on) {
        Store.prefs(c).edit().putBoolean("lock", on).apply();
    }

    static boolean deviceSecure(Context c) {
        KeyguardManager km = (KeyguardManager) c.getSystemService(Context.KEYGUARD_SERVICE);
        return km != null && km.isDeviceSecure();
    }

    static boolean needsUnlock(Context c) {
        return enabled(c) && System.currentTimeMillis() > unlockedUntil;
    }

    /** Called when the app goes to the background: stay unlocked for 2 more minutes. */
    static void onBackground() {
        if (unlockedUntil > 0) unlockedUntil = Math.min(unlockedUntil, System.currentTimeMillis() + 2 * 60 * 1000L);
    }

    static void markUnlocked() {
        unlockedUntil = Long.MAX_VALUE;
    }

    @SuppressWarnings("deprecation")
    static void prompt(Activity a, Runnable onSuccess, Runnable onFail) {
        if (Build.VERSION.SDK_INT >= 28) {
            BiometricPrompt.Builder b = new BiometricPrompt.Builder(a)
                    .setTitle("Unlock FinSight")
                    .setSubtitle("Your financial summary is protected");
            if (Build.VERSION.SDK_INT >= 30) {
                b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK
                        | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
            } else {
                b.setDeviceCredentialAllowed(true);
            }
            BiometricPrompt p = b.build();
            p.authenticate(new CancellationSignal(), a.getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                    markUnlocked();
                    onSuccess.run();
                }

                @Override
                public void onAuthenticationError(int errorCode, CharSequence errString) {
                    onFail.run();
                }
            });
        } else {
            KeyguardManager km = (KeyguardManager) a.getSystemService(Context.KEYGUARD_SERVICE);
            Intent i = km == null ? null : km.createConfirmDeviceCredentialIntent("Unlock FinSight", "Your financial summary is protected");
            if (i == null) {
                markUnlocked();
                onSuccess.run();
            } else {
                a.startActivityForResult(i, REQUEST_CREDENTIAL);
            }
        }
    }
}
