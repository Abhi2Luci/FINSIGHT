package com.abhishek.finsight;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import com.abhishek.finsight.core.ChatExport;
import com.abhishek.finsight.core.RawMessage;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Imports WhatsApp chat exports (.txt / .zip), Telegram Desktop exports (result.json) and pasted text. */
final class Importer {
    private Importer() {}

    static final class Result {
        int messages;
        int financial;
        int added;

        void add(int total, int[] r) {
            messages += total;
            financial += r[0];
            added += r[1];
        }

        String describe() {
            if (messages == 0) return "No messages found in that file.";
            return "Read " + messages + " messages: " + financial + " with financial details (" + added + " new).";
        }
    }

    static Result importUri(Context c, Uri uri) throws Exception {
        String name = displayName(c, uri);
        byte[] data = readAll(c.getContentResolver().openInputStream(uri), 60 * 1024 * 1024);
        Result r = new Result();
        importBytes(c, name, data, r);
        return r;
    }

    private static void importBytes(Context c, String name, byte[] data, Result r) throws Exception {
        String lname = name.toLowerCase(Locale.ROOT);
        boolean zip = data.length > 3 && data[0] == 'P' && data[1] == 'K';
        if (zip) {
            ZipInputStream z = new ZipInputStream(new ByteArrayInputStream(data));
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                String en = e.getName();
                String le = en.toLowerCase(Locale.ROOT);
                if (e.isDirectory() || !(le.endsWith(".txt") || le.endsWith(".json"))) continue;
                byte[] inner = readAll(z, 60 * 1024 * 1024, false);
                String base = en.contains("/") ? en.substring(en.lastIndexOf('/') + 1) : en;
                String chat = base.equals("_chat.txt") ? chatName(name) : chatName(base);
                importBytesInner(c, base, chat, inner, r);
            }
            z.close();
            return;
        }
        importBytesInner(c, lname, chatName(name), data, r);
    }

    private static void importBytesInner(Context c, String name, String chat, byte[] data, Result r) throws Exception {
        String text = new String(data, StandardCharsets.UTF_8);
        if (text.startsWith("﻿")) text = text.substring(1);
        String t = text.trim();
        if (name.toLowerCase(Locale.ROOT).endsWith(".json") || t.startsWith("{")) {
            List<RawMessage> msgs = telegram(t);
            r.add(msgs.size(), Store.get(c).saveFinancial(msgs));
        } else {
            importText(c, text, chat, r);
        }
    }

    static Result importText(Context c, String text, String chat) {
        Result r = new Result();
        importText(c, text, chat, r);
        return r;
    }

    private static void importText(Context c, String text, String chat, Result r) {
        String t = text.replace("\r\n", "\n");
        List<RawMessage> msgs = ChatExport.looksLikeWhatsApp(t)
                ? ChatExport.parseWhatsApp(t, "WhatsApp", chat)
                : ChatExport.parsePlain(t, "Imported text", chat == null ? "" : chat, System.currentTimeMillis());
        r.add(msgs.size(), Store.get(c).saveFinancial(msgs));
    }

    /** Telegram Desktop → Export chat history → JSON. Handles a single chat or a full account export. */
    private static List<RawMessage> telegram(String json) throws Exception {
        List<RawMessage> out = new ArrayList<>();
        JSONObject root = new JSONObject(json);
        if (root.has("messages")) {
            telegramChat(root, out);
        } else if (root.has("chats")) {
            JSONObject chats = root.getJSONObject("chats");
            JSONArray list = chats.optJSONArray("list");
            if (list != null) for (int i = 0; i < list.length(); i++) telegramChat(list.getJSONObject(i), out);
        }
        return out;
    }

    private static void telegramChat(JSONObject chat, List<RawMessage> out) {
        String chatName = chat.optString("name", "");
        JSONArray msgs = chat.optJSONArray("messages");
        if (msgs == null) return;
        for (int i = 0; i < msgs.length(); i++) {
            JSONObject m = msgs.optJSONObject(i);
            if (m == null || !"message".equals(m.optString("type", "message"))) continue;
            String text = telegramText(m.opt("text"));
            if (text.trim().isEmpty()) continue;
            long time;
            String unix = m.optString("date_unixtime", "");
            if (!unix.isEmpty()) {
                time = Long.parseLong(unix) * 1000L;
            } else {
                try {
                    time = LocalDateTime.parse(m.optString("date")).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
                } catch (Exception e) {
                    time = System.currentTimeMillis();
                }
            }
            String from = m.optString("from", chatName);
            String sender = chatName.isEmpty() || chatName.equals(from) ? from : chatName + " / " + from;
            out.add(new RawMessage("Telegram", sender, time, text));
        }
    }

    private static String telegramText(Object o) {
        if (o == null) return "";
        if (o instanceof String) return (String) o;
        if (o instanceof JSONArray) {
            JSONArray a = (JSONArray) o;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < a.length(); i++) {
                Object p = a.opt(i);
                if (p instanceof String) sb.append((String) p);
                else if (p instanceof JSONObject) sb.append(((JSONObject) p).optString("text", ""));
            }
            return sb.toString();
        }
        return String.valueOf(o);
    }

    static String chatName(String fileName) {
        if (fileName == null) return "";
        String n = fileName;
        int slash = n.lastIndexOf('/');
        if (slash >= 0) n = n.substring(slash + 1);
        n = n.replaceAll("(?i)\\.(txt|zip|json)$", "");
        n = n.replaceAll("(?i)^whatsapp chat (with|-)\\s*", "");
        n = n.replaceAll("\\s*\\(\\d+\\)$", "");
        return n.trim();
    }

    static String displayName(Context c, Uri uri) {
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cur != null && cur.moveToFirst()) {
                String s = cur.getString(0);
                if (s != null) return s;
            }
        } catch (Exception ignored) {
        } finally {
            if (cur != null) cur.close();
        }
        String last = uri.getLastPathSegment();
        return last == null ? "import" : last;
    }

    private static byte[] readAll(InputStream in, int max) throws Exception {
        return readAll(in, max, true);
    }

    private static byte[] readAll(InputStream in, int max, boolean close) throws Exception {
        if (in == null) throw new Exception("Could not open the file.");
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) {
            bo.write(buf, 0, n);
            if (bo.size() > max) throw new Exception("File is too large.");
        }
        if (close) in.close();
        return bo.toByteArray();
    }
}
