package com.abhishek.finsight;

import android.app.Activity;
import android.content.Intent;
import android.view.Gravity;
import android.widget.LinearLayout;

/** Base screen: asks for fingerprint / screen lock before showing anything. */
abstract class LockedActivity extends Activity {
    private static int started = 0;
    private boolean showing = false;
    private boolean prompting = false;

    /** Build the screen's content. Called after unlocking (and again whenever the screen should refresh). */
    protected abstract void render();

    @Override
    protected void onStart() {
        super.onStart();
        if (started == 0 && !Lock.needsUnlock(this)) Lock.markUnlocked();
        started++;
    }

    @Override
    protected void onStop() {
        super.onStop();
        started = Math.max(0, started - 1);
        if (started == 0) Lock.onBackground();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Lock.needsUnlock(this)) {
            if (prompting) return;
            showing = false;
            showLockScreen();
            ask();
        } else if (!showing) {
            showing = true;
            render();
        }
    }

    private void ask() {
        prompting = true;
        Lock.prompt(this, () -> {
            prompting = false;
            showing = true;
            render();
        }, () -> prompting = false);
    }

    private void showLockScreen() {
        LinearLayout l = Ui.vbox(this);
        l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(Ui.BG);
        int p = Ui.dp(this, 32);
        l.setPadding(p, p, p, p);
        l.addView(Ui.text(this, "FinSight is locked", 20, Ui.INK, true));
        l.addView(Ui.text(this, "Use your fingerprint, face or screen lock to open it.", 14, Ui.MUTED, false));
        l.addView(Ui.button(this, "Unlock", v -> { if (!prompting) ask(); }));
        setContentView(l);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Lock.REQUEST_CREDENTIAL) {
            prompting = false;
            if (resultCode == RESULT_OK) {
                Lock.markUnlocked();
                showing = true;
                render();
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
