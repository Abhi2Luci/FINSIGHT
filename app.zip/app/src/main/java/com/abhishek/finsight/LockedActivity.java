package com.abhishek.finsight;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Base screen: asks for fingerprint / screen lock before showing anything, and shows crash details if the app crashed. */
abstract class LockedActivity extends Activity {
    private static int started = 0;
    private boolean showing = false;
    private boolean prompting = false;
    private boolean showingCrash = false;

    /** Build the screen's content. Called after unlocking (and again whenever the screen should refresh). */
    protected abstract void render();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        String crash = App.takeCrash(this);
        if (!crash.isEmpty()) {
            showingCrash = true;
            showCrashScreen(crash);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (started == 0 && !Lock.needsUnlock(this)) Lock.markUnlocked();
        started++;
    }

    @Override
    protected void onStop() {
        super.onStop();
        started = Math.max(0, started - 1);
        if (started == 0) Lock.onBackground();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (showingCrash) return;
        if (Lock.needsUnlock(this)) {
            if (prompting) return;
            showing = false;
            showLockScreen();
            ask();
        } else if (!showing) {
            showing = true;
            safeRender();
        }
    }

    /** Runs render() and shows any error on screen instead of closing the app. */
    protected void safeRender() {
        try {
            render();
        } catch (Throwable t) {
            App.saveCrash(this, "screen", t);
            showingCrash = true;
            showCrashScreen(App.takeCrash(this));
        }
    }

    private void ask() {
        prompting = true;
        try {
            Lock.prompt(this, () -> {
                prompting = false;
                showing = true;
                safeRender();
            }, () -> prompting = false);
        } catch (Throwable t) {
            // the phone's fingerprint system refused the request: open without the lock rather than crash
            prompting = false;
            Lock.markUnlocked();
            Ui.toast(this, "Fingerprint lock is not available on this phone, opening without it.");
            Lock.setEnabled(this, false);
            showing = true;
            safeRender();
        }
    }

    private void showLockScreen() {
        LinearLayout l = Ui.vbox(this);
        l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(Ui.BG);
        int p = Ui.dp(this, 32);
        l.setPadding(p, p, p, p);
        l.addView(Ui.text(this, "FinSight is locked", 20, Ui.INK, true));
        l.addView(Ui.text(this, "Use your fingerprint, face or screen lock to open it.", 14, Ui.MUTED, false));
        l.addView(Ui.button(this, "Unlock", v -> { if (!prompting) ask(); }));
        setContentView(l);
    }

    private void showCrashScreen(String crash) {
        LinearLayout root = Ui.vbox(this);
        root.addView(Ui.text(this, "FinSight stopped last time", 19, Ui.INK, true));
        root.addView(Ui.text(this, "Tap \"Copy error\" and paste it to Claude so it can be fixed. Then tap \"Try again\".", 14, Ui.MUTED, false));
        root.addView(Ui.button(this, "Copy error", v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("FinSight error", crash));
            Ui.toast(this, "Error copied");
        }));
        root.addView(Ui.secondaryButton(this, "Try again", v -> {
            App.clearCrash(this);
            showingCrash = false;
            showing = false;
            recreate();
        }));
        root.addView(Ui.secondaryButton(this, "Try again without fingerprint lock", v -> {
            App.clearCrash(this);
            Lock.setEnabled(this, false);
            showingCrash = false;
            showing = false;
            recreate();
        }));
        LinearLayout box = Ui.card(this);
        TextView t = Ui.text(this, crash, 11, Ui.INK, false);
        t.setTextIsSelectable(true);
        box.addView(t);
        root.addView(box);
        setContentView(Ui.page(this, root));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Lock.REQUEST_CREDENTIAL) {
            prompting = false;
            if (resultCode == RESULT_OK) {
                Lock.markUnlocked();
                showing = true;
                safeRender();
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
