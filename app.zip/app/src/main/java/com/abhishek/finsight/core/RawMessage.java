package com.abhishek.finsight.core;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** One message from any source (SMS, Gmail, WhatsApp, Telegram, notification, pasted text). */
public class RawMessage {
    public final String source;
    public final String sender;
    public final long time;
    public final String text;

    public RawMessage(String source, String sender, long time, String text) {
        this.source = source == null ? "" : source;
        this.sender = sender == null ? "" : sender;
        this.time = time;
        this.text = text == null ? "" : text;
    }

    /** Stable key used to avoid storing the same message twice. */
    public String key() {
        return sha1(source + "|" + sender + "|" + (time / 60000L) + "|" + text);
    }

    public static String sha1(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] d = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return Integer.toHexString(s.hashCode());
        }
    }
}
